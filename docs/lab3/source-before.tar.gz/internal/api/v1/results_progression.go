package api

import (
	"context"
	"errors"
	"github.com/labstack/echo/v4"
	"sort"
	"time"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
)

func updateProgression(ctx context.Context, q DBTX, m contract.Match, winner *uuid.UUID) error {
	if m.NextMatchId != nil {
		if err := advanceSlot(ctx, q, *m.NextMatchId, string(*m.NextMatchSlot), winner); err != nil {
			return err
		}
	}
	if m.LoserNextMatchId != nil {
		loser := m.HomeApplicationId
		if optionalUUIDEqual(loser, winner) {
			loser = m.AwayApplicationId
		}
		if err := advanceSlot(ctx, q, *m.LoserNextMatchId, string(*m.LoserNextMatchSlot), loser); err != nil {
			return err
		}
	}
	return nil
}
func advanceSlot(ctx context.Context, q DBTX, id uuid.UUID, slot string, participant *uuid.UUID) error {
	if err := scheduleLock(ctx, q); err != nil {
		return err
	}
	next, err := readMatch(ctx, q, id, true)
	if err != nil {
		return err
	}
	existing := next.HomeApplicationId
	column := "home_application_id"
	if slot == "away" {
		existing = next.AwayApplicationId
		column = "away_application_id"
	}
	if optionalUUIDEqual(existing, participant) {
		return nil
	}
	if next.Status != contract.MatchStatusScheduled || (existing != nil && next.StartsAt != nil && !next.StartsAt.After(time.Now())) {
		return conflict("winner cannot change after a dependent match has started")
	}
	if _, err = q.Exec(ctx, `UPDATE matches SET `+column+`=$2,version=version+1,updated_at=now() WHERE id=$1`, id, participant); err != nil {
		return err
	}
	if slot == "away" {
		next.AwayApplicationId = participant
	} else {
		next.HomeApplicationId = participant
	}
	next.Version++
	return revalidateAdvancedSchedule(ctx, q, next)
}
func revalidateAdvancedSchedule(ctx context.Context, q DBTX, next contract.Match) error {
	if next.StartsAt == nil {
		return nil
	}
	t, err := readTournament(ctx, q, next.TournamentId, false)
	if err != nil {
		return err
	}
	err = scheduleConflict(ctx, q, t, next, *next.StartsAt)
	var httpErr *echo.HTTPError
	if err != nil && (!errors.As(err, &httpErr) || httpErr.Code != 409) {
		return err
	}
	if err == nil && next.StartsAt.After(time.Now()) {
		return nil
	}
	if _, err = q.Exec(ctx, `UPDATE matches SET starts_at=NULL,version=version+1,updated_at=now() WHERE id=$1`, next.Id); err != nil {
		return err
	}
	next.StartsAt = nil
	next.Version++
	if err = matchChanged(ctx, q, uuid.Nil, next, "match.unscheduled_after_advancement"); err != nil {
		return err
	}
	return notifyMatch(ctx, q, next, "match_unscheduled", "После определения участников требуется новое время матча")
}

func finishStage(ctx context.Context, tx pgx.Tx, t contract.Tournament, stageID uuid.UUID) error {
	var incomplete int
	var kind string
	if err := tx.QueryRow(ctx, `SELECT count(*) FILTER(WHERE status NOT IN ('completed','bye')) FROM matches WHERE stage_id=$1`, stageID).Scan(&incomplete); err != nil {
		return err
	}
	if incomplete > 0 {
		return nil
	}
	if err := tx.QueryRow(ctx, `UPDATE stages SET status='completed' WHERE id=$1 RETURNING kind`, stageID).Scan(&kind); err != nil {
		return err
	}
	if kind == "groups" {
		return startPlayoffs(ctx, tx, t, stageID)
	}
	var pending int
	if err := tx.QueryRow(ctx, `SELECT count(*) FROM stages WHERE tournament_id=$1 AND status<>'completed'`, t.Id).Scan(&pending); err != nil {
		return err
	}
	if pending == 0 {
		return finalizeTournament(ctx, tx, t.Id)
	}
	return nil
}
func qualifiedParticipants(ctx context.Context, q DBTX, t contract.Tournament, stageID uuid.UUID) ([]uuid.UUID, error) {
	tables, err := readStandings(ctx, q, t.Id)
	if err != nil {
		return nil, err
	}
	gs := t.Rules.GroupSettings
	selected := []uuid.UUID{}
	wildcards := []contract.Standing{}
	relevant := []contract.Standings{}
	for _, table := range tables {
		if table.StageId == stageID {
			relevant = append(relevant, table)
		}
	}
	for rank := 1; rank <= gs.QualifiersPerGroup; rank++ {
		for _, table := range relevant {
			for _, r := range table.Rows {
				if r.Position == rank {
					selected = append(selected, r.ApplicationId)
				}
			}
		}
	}
	if gs.WildcardCount == 0 {
		return selected, nil
	}
	for _, table := range relevant {
		for _, r := range table.Rows {
			if r.Position == *gs.WildcardPlace {
				wildcards = append(wildcards, r)
			}
		}
	}
	sort.Slice(wildcards, func(i, j int) bool {
		a, b := wildcards[i], wildcards[j]
		if a.Points != b.Points {
			return a.Points > b.Points
		}
		if a.ScoreDifference != b.ScoreDifference {
			return a.ScoreDifference > b.ScoreDifference
		}
		if a.ScoreFor != b.ScoreFor {
			return a.ScoreFor > b.ScoreFor
		}
		return a.ApplicationId.String() < b.ApplicationId.String()
	})
	for i := 0; i < gs.WildcardCount; i++ {
		selected = append(selected, wildcards[i].ApplicationId)
	}
	return selected, nil
}
func startPlayoffs(ctx context.Context, tx pgx.Tx, t contract.Tournament, groupStage uuid.UUID) error {
	ids, err := qualifiedParticipants(ctx, tx, t, groupStage)
	if err != nil {
		return err
	}
	var s contract.Stage
	err = tx.QueryRow(ctx, `SELECT id,tournament_id,kind,position,status FROM stages WHERE tournament_id=$1 AND kind='playoffs' FOR UPDATE`, t.Id).Scan(&s.Id, &s.TournamentId, &s.Kind, &s.Position, &s.Status)
	if err != nil {
		return err
	}
	existing, err := matchList(ctx, tx, `SELECT `+matchColumns+` FROM matches m WHERE m.stage_id=$1 ORDER BY m.round,m.position`, s.Id)
	if err != nil {
		return err
	}
	matches, err := playoffMatches(t, s, ids)
	if err != nil {
		return err
	}
	if err = scheduleLock(ctx, tx); err != nil {
		return err
	}
	if len(existing) > 0 {
		if firstRoundSame(existing, matches) {
			return nil
		}
		for _, m := range existing {
			if m.Status == contract.MatchStatusCompleted || m.Status == contract.MatchStatusAwaitingConfirmation || m.Status == contract.MatchStatusDisputed || (m.StartsAt != nil && !m.StartsAt.After(time.Now())) {
				return conflict("group correction changes qualifiers after playoffs started")
			}
		}
		if _, err = tx.Exec(ctx, `DELETE FROM matches WHERE stage_id=$1`, s.Id); err != nil {
			return err
		}
	}
	if err = saveMatches(ctx, tx, matches); err != nil {
		return err
	}
	if _, err = tx.Exec(ctx, `UPDATE stages SET status='in_progress' WHERE id=$1`, s.Id); err != nil {
		return err
	}
	return event(ctx, tx, t.Id, "bracket_updated", map[string]any{"stage_id": s.Id, "matches": matches})
}

// finalizeTournament сохраняет места после завершения всех этапов и матчей.
func finalizeTournament(ctx context.Context, tx pgx.Tx, tournamentID uuid.UUID) error {
	var total, unfinished int
	if err := tx.QueryRow(ctx, `SELECT count(*),count(*) FILTER(WHERE status NOT IN ('completed','bye')) FROM matches WHERE tournament_id=$1`, tournamentID).Scan(&total, &unfinished); err != nil {
		return err
	}
	if total == 0 || unfinished > 0 {
		return conflict("all matches must be completed")
	}
	t, err := readTournament(ctx, tx, tournamentID, false)
	if err != nil {
		return err
	}
	if err = assignFinalPlaces(ctx, tx, t); err != nil {
		return err
	}
	if _, err = tx.Exec(ctx, `UPDATE stages SET status='completed' WHERE tournament_id=$1`, tournamentID); err != nil {
		return err
	}
	if _, err = tx.Exec(ctx, `UPDATE tournaments SET status='completed',version=version+1,updated_at=now() WHERE id=$1`, tournamentID); err != nil {
		return err
	}
	return event(ctx, tx, tournamentID, "tournament_updated", map[string]any{"status": "completed"})
}
func assignFinalPlaces(ctx context.Context, q DBTX, t contract.Tournament) error {
	if t.Format == contract.TournamentFormatRoundRobin {
		_, err := q.Exec(ctx, `UPDATE applications a SET final_place=s.position FROM standings s WHERE s.application_id=a.id AND a.tournament_id=$1`, t.Id)
		return err
	}
	// Проигравшие в одном туре делят место; group stage дополняет места выбывших.
	if _, err := q.Exec(ctx, `UPDATE applications SET final_place=NULL WHERE tournament_id=$1`, t.Id); err != nil {
		return err
	}
	if err := playoffPlaces(ctx, q, t); err != nil {
		return err
	}
	_, err := q.Exec(ctx, `WITH ranked AS(SELECT a.id,rank() OVER(ORDER BY s.position) AS pos FROM applications a JOIN standings s ON s.application_id=a.id WHERE a.tournament_id=$1 AND a.final_place IS NULL),base AS(SELECT count(*) AS n FROM applications WHERE tournament_id=$1 AND final_place IS NOT NULL) UPDATE applications a SET final_place=(ranked.pos+base.n)::int FROM ranked,base WHERE a.id=ranked.id`, t.Id)
	return err
}
func playoffPlaces(ctx context.Context, q DBTX, t contract.Tournament) error {
	matches, err := matchList(ctx, q, `SELECT `+matchColumns+` FROM matches m JOIN stages s ON s.id=m.stage_id WHERE m.tournament_id=$1 AND s.kind='playoffs' ORDER BY m.round DESC,m.position`, t.Id)
	if err != nil {
		return err
	}
	if len(matches) == 0 {
		return conflict("playoffs have no matches")
	}
	maxRound := matches[0].Round
	for _, m := range matches {
		if m.Status == contract.MatchStatusBye || m.WinnerApplicationId == nil {
			continue
		}
		loser := m.HomeApplicationId
		if optionalUUIDEqual(loser, m.WinnerApplicationId) {
			loser = m.AwayApplicationId
		}
		place := 1 << (maxRound - m.Round)
		place++
		if m.Round == maxRound && m.Position == 1 {
			if _, err = q.Exec(ctx, `UPDATE applications SET final_place=1 WHERE id=$1`, m.WinnerApplicationId); err != nil {
				return err
			}
			place = 2
		}
		if m.Round == maxRound && m.Position == 2 {
			if _, err = q.Exec(ctx, `UPDATE applications SET final_place=3 WHERE id=$1`, m.WinnerApplicationId); err != nil {
				return err
			}
			place = 4
		}
		if _, err = q.Exec(ctx, `UPDATE applications SET final_place=$2 WHERE id=$1 AND final_place IS NULL`, loser, place); err != nil {
			return err
		}
	}
	return nil
}

func firstRoundSame(existing, expected []contract.Match) bool {
	old := []contract.Match{}
	want := []contract.Match{}
	for _, m := range existing {
		if m.Round == 1 {
			old = append(old, m)
		}
	}
	for _, m := range expected {
		if m.Round == 1 {
			want = append(want, m)
		}
	}
	if len(old) != len(want) {
		return false
	}
	for i := range old {
		if old[i].Position != want[i].Position || !optionalUUIDEqual(old[i].HomeApplicationId, want[i].HomeApplicationId) || !optionalUUIDEqual(old[i].AwayApplicationId, want[i].AwayApplicationId) {
			return false
		}
	}
	return true
}
