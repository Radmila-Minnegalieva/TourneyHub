package api

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

func jsonItems[T any](ctx context.Context, q DBTX, sql string, args ...any) ([]T, error) {
	rows, err := q.Query(ctx, sql, args...)
	if err != nil {
		return nil, dbError(err)
	}
	defer rows.Close()
	items := make([]T, 0)
	for rows.Next() {
		var raw []byte
		if err := rows.Scan(&raw); err != nil {
			return nil, err
		}
		var item T
		if err := json.Unmarshal(raw, &item); err != nil {
			return nil, err
		}
		items = append(items, item)
	}
	return items, rows.Err()
}

func jsonObject[T any](ctx context.Context, q DBTX, sql string, args ...any) (T, error) {
	var item T
	var raw []byte
	if err := q.QueryRow(ctx, sql, args...).Scan(&raw); err != nil {
		return item, dbError(err)
	}
	err := json.Unmarshal(raw, &item)
	return item, err
}

func (a *API) ListDisciplines(c echo.Context, p contract.ListDisciplinesParams) error {
	l, o := pagination(p.Limit, p.Offset)
	ctx := c.Request().Context()
	var total int
	if err := a.db.QueryRow(ctx, `SELECT count(*) FROM disciplines WHERE active`).Scan(&total); err != nil {
		return err
	}
	items, err := jsonItems[contract.Discipline](ctx, a.db, `SELECT to_jsonb(d) FROM disciplines d WHERE active ORDER BY lower(name),id LIMIT $1 OFFSET $2`, l, o)
	if err != nil {
		return err
	}
	return c.JSON(200, contract.DisciplinePage{Items: items, Total: total, Limit: l, Offset: o})
}

func validateDiscipline(d contract.DisciplineRequest) error {
	if strings.TrimSpace(d.Name) == "" || strings.TrimSpace(d.ScoreUnit) == "" {
		return invalid("name and score_unit must not be blank")
	}
	if d.MinRosterSize > d.MaxRosterSize {
		return invalid("min_roster_size exceeds max_roster_size")
	}
	return nil
}

func (a *API) CreateDiscipline(c echo.Context) error {
	if err := requireRole(c, contract.Admin); err != nil {
		return err
	}
	var req contract.DisciplineRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	if err := validateDiscipline(req); err != nil {
		return err
	}
	var result contract.Discipline
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		var err error
		result, err = jsonObject[contract.Discipline](ctx, tx, `INSERT INTO disciplines(name,min_roster_size,max_roster_size,allows_draw,score_unit) VALUES($1,$2,$3,$4,$5) RETURNING to_jsonb(disciplines)`, strings.TrimSpace(req.Name), req.MinRosterSize, req.MaxRosterSize, req.AllowsDraw, strings.TrimSpace(req.ScoreUnit))
		if err != nil {
			return err
		}
		return audit(ctx, tx, currentUser(c), "discipline_created", "discipline", result.Id, nil, result)
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusCreated, result)
}

func (a *API) UpdateDiscipline(c echo.Context, id uuid.UUID) error {
	if err := requireRole(c, contract.Admin); err != nil {
		return err
	}
	var req contract.UpdateDisciplineRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var result contract.Discipline
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		old, err := jsonObject[contract.Discipline](ctx, tx, `SELECT to_jsonb(d) FROM disciplines d WHERE id=$1 FOR UPDATE`, id)
		if err != nil {
			return err
		}
		if old.Version != req.Version {
			return conflict("stale discipline version")
		}
		result = old
		if req.Name != nil {
			result.Name = *req.Name
		}
		if req.MinRosterSize != nil {
			result.MinRosterSize = *req.MinRosterSize
		}
		if req.MaxRosterSize != nil {
			result.MaxRosterSize = *req.MaxRosterSize
		}
		if req.AllowsDraw != nil {
			result.AllowsDraw = *req.AllowsDraw
		}
		if req.ScoreUnit != nil {
			result.ScoreUnit = *req.ScoreUnit
		}
		if req.Active != nil {
			result.Active = *req.Active
		}
		if err := validateDiscipline(contract.DisciplineRequest{Name: result.Name, MinRosterSize: result.MinRosterSize, MaxRosterSize: result.MaxRosterSize, AllowsDraw: result.AllowsDraw, ScoreUnit: result.ScoreUnit}); err != nil {
			return err
		}
		result, err = jsonObject[contract.Discipline](ctx, tx, `UPDATE disciplines SET name=$2,min_roster_size=$3,max_roster_size=$4,allows_draw=$5,score_unit=$6,active=$7,version=version+1 WHERE id=$1 RETURNING to_jsonb(disciplines)`, id, result.Name, result.MinRosterSize, result.MaxRosterSize, result.AllowsDraw, result.ScoreUnit, result.Active)
		if err != nil {
			return err
		}
		return audit(ctx, tx, currentUser(c), "discipline_updated", "discipline", id, old, result)
	})
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}

func (a *API) ListRatings(c echo.Context, p contract.ListRatingsParams) error {
	l, o := pagination(p.Limit, p.Offset)
	ctx := c.Request().Context()
	var total int
	if err := a.db.QueryRow(ctx, `SELECT count(*) FROM ratings r JOIN teams t ON t.id=r.team_id WHERE r.discipline_id=$1 AND t.deleted_at IS NULL`, p.DisciplineId).Scan(&total); err != nil {
		return err
	}
	items, err := jsonItems[contract.Rating](ctx, a.db, `SELECT jsonb_build_object('discipline_id',r.discipline_id,'played',r.played,'position',row_number() OVER(ORDER BY r.value DESC,t.id),'value',r.value,'team',to_jsonb(t)||jsonb_build_object('logo_url',CASE WHEN t.logo_file_id IS NOT NULL THEN '/api/v1/files/'||t.logo_file_id END)) FROM ratings r JOIN teams t ON t.id=r.team_id WHERE r.discipline_id=$1 AND t.deleted_at IS NULL ORDER BY r.value DESC,t.id LIMIT $2 OFFSET $3`, p.DisciplineId, l, o)
	if err != nil {
		return err
	}
	return c.JSON(200, contract.RatingPage{Items: items, Total: total, Limit: l, Offset: o})
}

func (a *API) ListRatingHistory(c echo.Context, id uuid.UUID, p contract.ListRatingHistoryParams) error {
	ctx := c.Request().Context()
	l, o := pagination(p.Limit, p.Offset)
	var exists bool
	if err := a.db.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM teams WHERE id=$1 AND deleted_at IS NULL)`, id).Scan(&exists); err != nil {
		return err
	}
	if !exists {
		return notFound("team not found")
	}
	var total int
	if err := a.db.QueryRow(ctx, `SELECT count(*) FROM rating_changes WHERE team_id=$1 AND discipline_id=$2`, id, p.DisciplineId).Scan(&total); err != nil {
		return err
	}
	items, err := jsonItems[contract.RatingChange](ctx, a.db, `SELECT to_jsonb(r) FROM rating_changes r WHERE team_id=$1 AND discipline_id=$2 ORDER BY created_at DESC,id LIMIT $3 OFFSET $4`, id, p.DisciplineId, l, o)
	if err != nil {
		return err
	}
	return c.JSON(200, contract.RatingChangePage{Items: items, Total: total, Limit: l, Offset: o})
}

func (a *API) ListNotifications(c echo.Context, p contract.ListNotificationsParams) error {
	ctx := c.Request().Context()
	l, o := pagination(p.Limit, p.Offset)
	var total int
	if err := a.db.QueryRow(ctx, `SELECT count(*) FROM notifications WHERE user_id=$1 AND ($2::boolean IS NOT TRUE OR read_at IS NULL)`, currentUser(c), p.Unread).Scan(&total); err != nil {
		return err
	}
	items, err := jsonItems[contract.Notification](ctx, a.db, `SELECT to_jsonb(n) FROM notifications n WHERE user_id=$1 AND ($2::boolean IS NOT TRUE OR read_at IS NULL) ORDER BY created_at DESC,id LIMIT $3 OFFSET $4`, currentUser(c), p.Unread, l, o)
	if err != nil {
		return err
	}
	return c.JSON(200, contract.NotificationPage{Items: items, Total: total, Limit: l, Offset: o})
}

func (a *API) ReadNotification(c echo.Context, id uuid.UUID) error {
	tag, err := a.db.Exec(c.Request().Context(), `UPDATE notifications SET read_at=coalesce(read_at,now()) WHERE id=$1 AND user_id=$2`, id, currentUser(c))
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return notFound("notification not found")
	}
	return c.NoContent(204)
}
