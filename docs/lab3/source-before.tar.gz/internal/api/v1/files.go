package api

import (
	"bytes"
	"fmt"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"mime"
	"net/http"
	"path/filepath"
	"strings"
	"unicode/utf8"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

const maxFileBytes = 5 * 1024 * 1024

func validateFile(data []byte, purpose string) (string, error) {
	if len(data) == 0 || len(data) > maxFileBytes {
		return "", invalid("file must contain 1..5242880 bytes")
	}
	contentType := http.DetectContentType(data)
	switch contentType {
	case "image/png", "image/jpeg":
		cfg, _, err := image.DecodeConfig(bytes.NewReader(data))
		if err != nil {
			return "", invalid("invalid image")
		}
		if cfg.Width > 10000 || cfg.Height > 10000 {
			return "", invalid("image dimensions exceed 10000 pixels")
		}
	case "application/pdf":
		if purpose != "match_protocol" {
			return "", invalid("PDF is only supported for match protocols")
		}
	default:
		return "", invalid("only PDF, PNG and JPEG files are supported")
	}
	return contentType, nil
}

func (a *API) UploadFile(c echo.Context) error {
	if err := requireRole(c, contract.Participant); err != nil {
		return err
	}
	if err := c.Request().ParseMultipartForm(6 * 1024 * 1024); err != nil {
		return echo.NewHTTPError(400, "invalid multipart body").SetInternal(err)
	}
	defer c.Request().MultipartForm.RemoveAll()
	purpose := c.FormValue("purpose")
	if purpose != "avatar" && purpose != "team_logo" && purpose != "match_protocol" {
		return invalid("invalid file purpose")
	}
	file, err := c.FormFile("file")
	if err != nil {
		return echo.NewHTTPError(400, "file is required")
	}
	stream, err := file.Open()
	if err != nil {
		return err
	}
	defer stream.Close()
	data, err := io.ReadAll(io.LimitReader(stream, maxFileBytes+1))
	if err != nil {
		return err
	}
	contentType, err := validateFile(data, purpose)
	if err != nil {
		return err
	}
	name := filepath.Base(strings.ReplaceAll(file.Filename, "\\", "/"))
	if name == "." || name == "" || utf8.RuneCountInString(name) > 255 || strings.ContainsAny(name, "\r\n\x00") {
		return invalid("invalid file name")
	}
	var result contract.File
	err = a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		id := uuid.New()
		var err error
		result, err = jsonObject[contract.File](ctx, tx, `INSERT INTO files(id,owner_id,purpose,storage_key,filename,content_type,size_bytes,data) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING to_jsonb(files)-'data'`, id, currentUser(c), purpose, id.String(), name, contentType, len(data), data)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(201, result)
}

func (a *API) DownloadFile(c echo.Context, id uuid.UUID) error {
	ctx := c.Request().Context()
	var purpose, name, contentType string
	var owner uuid.UUID
	var data []byte
	if err := a.db.QueryRow(ctx, `SELECT owner_id,purpose,filename,content_type,data FROM files WHERE id=$1`, id).Scan(&owner, &purpose, &name, &contentType, &data); err != nil {
		return dbError(err)
	}
	if purpose == "match_protocol" && owner != currentUser(c) && !hasRole(c, contract.Admin) {
		allowed, err := a.canReadProtocol(c, id)
		if err != nil {
			return err
		}
		if !allowed {
			return forbidden("file is private")
		}
	}
	c.Response().Header().Set("X-Content-Type-Options", "nosniff")
	c.Response().Header().Set("Content-Security-Policy", "default-src 'none'; sandbox")
	c.Response().Header().Set("Content-Disposition", mime.FormatMediaType("attachment", map[string]string{"filename": name}))
	c.Response().Header().Set("Cache-Control", "private, max-age=0")
	return c.Blob(200, contentType, data)
}

func (a *API) canReadProtocol(c echo.Context, id uuid.UUID) (bool, error) {
	if currentUser(c) == uuid.Nil {
		return false, nil
	}
	var allowed bool
	err := a.db.QueryRow(c.Request().Context(), `SELECT EXISTS(
 SELECT 1 FROM matches m JOIN tournaments t ON t.id=m.tournament_id
 WHERE (EXISTS(SELECT 1 FROM report_files rf JOIN result_reports r ON r.id=rf.report_id WHERE rf.file_id=$1 AND r.match_id=m.id)
 OR EXISTS(SELECT 1 FROM dispute_files df JOIN disputes d ON d.id=df.dispute_id WHERE df.file_id=$1 AND d.match_id=m.id))
 AND (t.organizer_id=$2 OR t.referee_id=$2 OR m.referee_id=$2
 OR EXISTS(SELECT 1 FROM application_players ap WHERE ap.application_id IN (m.home_application_id,m.away_application_id) AND ap.user_id=$2)
 OR EXISTS(SELECT 1 FROM applications a JOIN teams tm ON tm.id=a.team_id WHERE a.id IN (m.home_application_id,m.away_application_id) AND tm.captain_id=$2)))`, id, currentUser(c)).Scan(&allowed)
	return allowed, err
}

// csvCell предотвращает интерпретацию названий как формул при импорте CSV.
func csvCell(value string) string {
	trimmed := strings.TrimLeft(value, " \t\r\n")
	if trimmed != "" && strings.ContainsRune("=+-@", rune(trimmed[0])) {
		return "'" + value
	}
	return value
}

func fileURL(id uuid.UUID) string { return fmt.Sprintf("/api/v1/files/%s", id) }
