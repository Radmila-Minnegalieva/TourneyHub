package api

import (
	"context"
	cryptorand "crypto/rand"
	"encoding/json"
	"fmt"
	"math/big"
	"time"

	"github.com/Radmila-Minnegalieva/TourneyHub/backend/internal/model"
	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

func acceptedIDs(ctx context.Context, q DBTX, t contract.Tournament) ([]uuid.UUID, error) {
	rows, err := q.Query(ctx, `SELECT a.id FROM applications a LEFT JOIN ratings r ON r.team_id=a.team_id AND r.discipline_id=$2 WHERE a.tournament_id=$1 AND a.status='accepted' ORDER BY coalesce(r.value,1500) DESC,a.created_at,a.id`, t.Id, t.DisciplineId)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	ids := []uuid.UUID{}
	for rows.Next() {
		var id uuid.UUID
		if err = rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}
func orderSeeds(ids []uuid.UUID, req contract.SeedingRequest) ([]uuid.UUID, error) {
	if req.Method == contract.SeedingRequestMethodManual {
		if req.ApplicationIds == nil || len(*req.ApplicationIds) != len(ids) {
			return nil, invalid("manual seeding needs all accepted applications")
		}
		expected := map[uuid.UUID]bool{}
		for _, id := range ids {
			expected[id] = true
		}
		for _, id := range *req.ApplicationIds {
			if !expected[id] {
				return nil, invalid("manual seeding must be a permutation")
			}
			delete(expected, id)
		}
		return *req.ApplicationIds, nil
	}
	if req.Method != contract.SeedingRequestMethodRandom {
		return ids, nil
	}
	for i := len(ids) - 1; i > 0; i-- {
		j, err := cryptorand.Int(cryptorand.Reader, big.NewInt(int64(i+1)))
		if err != nil {
			return nil, err
		}
		ids[i], ids[j.Int64()] = ids[j.Int64()], ids[i]
	}
	return ids, nil
}
func drawAvailable(ctx context.Context, q DBTX, t contract.Tournament) error {
	if t.Status != contract.TournamentStatusRegistration && t.Status != contract.TournamentStatusInProgress {
		return conflict("draw requires a published active tournament")
	}
	var started bool
	err := q.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM result_reports r JOIN matches m ON m.id=r.match_id WHERE m.tournament_id=$1)`, t.Id).Scan(&started)
	if err != nil {
		return err
	}
	if started {
		return conflict("cannot rebuild after the first result")
	}
	return nil
}
func buildDraw(t contract.Tournament, ids []uuid.UUID) (contract.DrawPreview, error) {
	p := contract.DrawPreview{Id: uuid.New(), TournamentId: t.Id, TournamentVersion: t.Version, ExpiresAt: time.Now().UTC().Add(time.Hour), Stages: []contract.Stage{}, Groups: []contract.Group{}, Matches: []contract.Match{}, Seeds: []contract.Seed{}}
	for i, id := range ids {
		p.Seeds = append(p.Seeds, contract.Seed{ApplicationId: id, Position: i + 1})
	}
	switch t.Format {
	case contract.TournamentFormatSingleElimination:
		if t.Rules.ThirdPlaceMatch && len(ids) < 4 {
			return p, invalid("third-place match needs at least four participants")
		}
		stage := newStage(t.Id, contract.StageKindPlayoffs, 1, contract.StageStatusInProgress)
		p.Stages = append(p.Stages, stage)
		matches, err := playoffMatches(t, stage, ids)
		p.Matches = matches
		return p, err
	case contract.TournamentFormatRoundRobin:
		stage := newStage(t.Id, contract.StageKindRoundRobin, 1, contract.StageStatusInProgress)
		p.Stages = append(p.Stages, stage)
		matches, err := roundRobinMatches(t, stage, nil, ids)
		p.Matches = matches
		return p, err
	default:
		return buildGroupDraw(t, ids, p)
	}
}
func newStage(tid uuid.UUID, kind contract.StageKind, pos int, status contract.StageStatus) contract.Stage {
	return contract.Stage{Id: uuid.New(), TournamentId: tid, Kind: kind, Position: pos, Status: status}
}
func baseMatch(t contract.Tournament, s contract.Stage, round, pos int) contract.Match {
	return contract.Match{Id: uuid.New(), TournamentId: t.Id, StageId: s.Id, Round: round, Position: pos, Status: contract.MatchStatusScheduled, Version: 1}
}
func roundRobinMatches(t contract.Tournament, s contract.Stage, gid *uuid.UUID, ids []uuid.UUID) ([]contract.Match, error) {
	pairs, err := model.RoundRobin(len(ids), int(t.Rules.RoundRobinLegs))
	if err != nil {
		return nil, invalid(err.Error())
	}
	result := make([]contract.Match, 0, len(pairs))
	for _, pair := range pairs {
		m := baseMatch(t, s, pair.Round, pair.Position)
		m.HomeApplicationId = &ids[pair.Home]
		m.AwayApplicationId = &ids[pair.Away]
		m.GroupId = gid
		result = append(result, m)
	}
	return result, nil
}
func playoffMatches(t contract.Tournament, s contract.Stage, ids []uuid.UUID) ([]contract.Match, error) {
	order, err := model.SeedOrder(len(ids))
	if err != nil {
		return nil, invalid(err.Error())
	}
	rounds := [][]contract.Match{}
	for count, round := len(order)/2, 1; count >= 1; count, round = count/2, round+1 {
		matches := make([]contract.Match, count)
		for i := range matches {
			matches[i] = baseMatch(t, s, round, i+1)
		}
		rounds = append(rounds, matches)
	}
	for i := range rounds[0] {
		m := &rounds[0][i]
		h, a := order[2*i]-1, order[2*i+1]-1
		if h < len(ids) {
			m.HomeApplicationId = &ids[h]
		}
		if a < len(ids) {
			m.AwayApplicationId = &ids[a]
		}
	}
	linkPlayoffRounds(rounds)
	result := []contract.Match{}
	for _, round := range rounds {
		result = append(result, round...)
	}
	if t.Rules.ThirdPlaceMatch && len(rounds) > 1 {
		third := baseMatch(t, s, len(rounds), 2)
		semis := len(result) - 3
		home, away := contract.MatchLoserNextMatchSlot("home"), contract.MatchLoserNextMatchSlot("away")
		result[semis].LoserNextMatchId = &third.Id
		result[semis].LoserNextMatchSlot = &home
		result[semis+1].LoserNextMatchId = &third.Id
		result[semis+1].LoserNextMatchSlot = &away
		result = append(result, third)
	}
	for i := 0; i < len(order)/2; i++ {
		m := &result[i]
		if m.HomeApplicationId == nil || m.AwayApplicationId == nil {
			m.Status = contract.MatchStatusBye
			m.WinnerApplicationId = m.HomeApplicationId
			if m.WinnerApplicationId == nil {
				m.WinnerApplicationId = m.AwayApplicationId
			}
			fillWinner(result, *m)
		}
	}
	return result, nil
}
func linkPlayoffRounds(rounds [][]contract.Match) {
	for r := 0; r < len(rounds)-1; r++ {
		for i := range rounds[r] {
			next := &rounds[r+1][i/2]
			slot := contract.MatchNextMatchSlot("home")
			if i%2 == 1 {
				slot = "away"
			}
			rounds[r][i].NextMatchId = &next.Id
			rounds[r][i].NextMatchSlot = &slot
		}
	}
}
func fillWinner(matches []contract.Match, m contract.Match) {
	if m.NextMatchId == nil {
		return
	}
	for i := range matches {
		if matches[i].Id == *m.NextMatchId {
			if *m.NextMatchSlot == "home" {
				matches[i].HomeApplicationId = m.WinnerApplicationId
			} else {
				matches[i].AwayApplicationId = m.WinnerApplicationId
			}
			return
		}
	}
}
func buildGroupDraw(t contract.Tournament, ids []uuid.UUID, p contract.DrawPreview) (contract.DrawPreview, error) {
	gs := t.Rules.GroupSettings
	if gs == nil {
		return p, invalid("group settings are required")
	}
	groups, err := model.SnakeGroups(len(ids), gs.GroupCount)
	if err != nil {
		return p, invalid(err.Error())
	}
	if t.Rules.ThirdPlaceMatch && gs.GroupCount*gs.QualifiersPerGroup+gs.WildcardCount < 4 {
		return p, invalid("third-place match needs at least four playoff qualifiers")
	}
	minSize := len(ids) / gs.GroupCount
	if gs.QualifiersPerGroup > minSize || gs.QualifiersPerGroup < 1 {
		return p, invalid("qualifiers cannot exceed the number of participants in a group")
	}
	if gs.WildcardCount > 0 && (gs.WildcardPlace == nil || *gs.WildcardPlace <= gs.QualifiersPerGroup || *gs.WildcardPlace > minSize || gs.WildcardCount > gs.GroupCount) {
		return p, invalid("invalid wildcard settings")
	}
	stage := newStage(t.Id, contract.StageKindGroups, 1, contract.StageStatusInProgress)
	p.Stages = append(p.Stages, stage, newStage(t.Id, contract.StageKindPlayoffs, 2, contract.StageStatusPending))
	for i, indices := range groups {
		group := contract.Group{Id: uuid.New(), StageId: stage.Id, Name: fmt.Sprintf("%c", 'A'+rune(i)), ApplicationIds: []uuid.UUID{}}
		for _, j := range indices {
			group.ApplicationIds = append(group.ApplicationIds, ids[j])
		}
		matches, e := roundRobinMatches(t, stage, &group.Id, group.ApplicationIds)
		if e != nil {
			return p, e
		}
		// position уникальна в пределах этапа и тура, включая разные группы.
		for j := range matches {
			matches[j].Position += i * 128
		}
		p.Groups = append(p.Groups, group)
		p.Matches = append(p.Matches, matches...)
	}
	return p, nil
}
func (a *API) PreviewDraw(c echo.Context, id uuid.UUID) error {
	var req contract.SeedingRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	ctx := c.Request().Context()
	var result contract.DrawPreview
	err := a.withTx(c, func(tx pgx.Tx) error {
		t, err := readTournament(ctx, tx, id, true)
		if err != nil {
			return err
		}
		if err = requireTournamentOwner(c, t); err != nil {
			return err
		}
		if t.Version != req.Version {
			return conflict("tournament version is stale")
		}
		if err = drawAvailable(ctx, tx, t); err != nil {
			return err
		}
		ids, err := acceptedIDs(ctx, tx, t)
		if err != nil {
			return err
		}
		if len(ids) < 2 {
			return invalid("draw requires at least two accepted applications")
		}
		ids, err = orderSeeds(ids, req)
		if err != nil {
			return err
		}
		result, err = buildDraw(t, ids)
		if err != nil {
			return err
		}
		data, err := json.Marshal(result)
		if err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `INSERT INTO draw_previews(id,tournament_id,tournament_version,created_by,method,payload,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7)`, result.Id, id, t.Version, currentUser(c), req.Method, data, result.ExpiresAt)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(201, result)
}
func (a *API) ConfirmDraw(c echo.Context, id uuid.UUID) error {
	var req contract.ConfirmDrawRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	ctx := c.Request().Context()
	var result contract.Bracket
	err := a.withTx(c, func(tx pgx.Tx) error {
		t, err := readTournament(ctx, tx, id, true)
		if err != nil {
			return err
		}
		if err = requireTournamentOwner(c, t); err != nil {
			return err
		}
		var raw []byte
		var confirmed *time.Time
		err = tx.QueryRow(ctx, `SELECT payload,confirmed_at FROM draw_previews WHERE id=$1 AND tournament_id=$2 FOR UPDATE`, req.PreviewId, id).Scan(&raw, &confirmed)
		if err != nil {
			return dbError(err)
		}
		var preview contract.DrawPreview
		if err = json.Unmarshal(raw, &preview); err != nil {
			return err
		}
		if confirmed != nil {
			result, err = readBracket(ctx, tx, id)
			return err
		}
		if t.Version != req.Version || preview.TournamentVersion != t.Version {
			return conflict("draw preview version is stale")
		}
		if time.Now().After(preview.ExpiresAt) {
			return conflict("draw preview expired")
		}
		if err = drawAvailable(ctx, tx, t); err != nil {
			return err
		}
		ids, err := acceptedIDs(ctx, tx, t)
		if err != nil {
			return err
		}
		if !sameDrawParticipants(ids, preview.Seeds) {
			return conflict("accepted participants changed")
		}
		if err = clearDraw(ctx, tx, id); err != nil {
			return err
		}
		if err = saveDraw(ctx, tx, preview); err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE draw_previews SET confirmed_at=now() WHERE id=$1`, req.PreviewId); err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE tournaments SET status='in_progress',version=version+1,updated_at=now() WHERE id=$1`, id); err != nil {
			return err
		}
		if err = audit(ctx, tx, currentUser(c), "draw.confirmed", "tournament", id, nil, preview); err != nil {
			return err
		}
		result = contract.Bracket{Stages: preview.Stages, Groups: preview.Groups, Matches: preview.Matches}
		return event(ctx, tx, id, "bracket_updated", result)
	})
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}
func sameDrawParticipants(ids []uuid.UUID, seeds []contract.Seed) bool {
	if len(ids) != len(seeds) {
		return false
	}
	set := map[uuid.UUID]bool{}
	for _, id := range ids {
		set[id] = true
	}
	for _, s := range seeds {
		if !set[s.ApplicationId] {
			return false
		}
		delete(set, s.ApplicationId)
	}
	return len(set) == 0
}
func clearDraw(ctx context.Context, q DBTX, id uuid.UUID) error {
	for _, query := range []string{`DELETE FROM standings WHERE tournament_id=$1`, `DELETE FROM matches WHERE tournament_id=$1`, `DELETE FROM group_participants WHERE tournament_id=$1`, `DELETE FROM tournament_groups WHERE tournament_id=$1`, `DELETE FROM stages WHERE tournament_id=$1`} {
		if _, err := q.Exec(ctx, query, id); err != nil {
			return err
		}
	}
	_, err := q.Exec(ctx, `UPDATE applications SET seed=NULL,final_place=NULL WHERE tournament_id=$1`, id)
	return err
}
func saveDraw(ctx context.Context, q DBTX, p contract.DrawPreview) error {
	for _, seed := range p.Seeds {
		if _, err := q.Exec(ctx, `UPDATE applications SET seed=$2 WHERE id=$1`, seed.ApplicationId, seed.Position); err != nil {
			return err
		}
	}
	for _, s := range p.Stages {
		if _, err := q.Exec(ctx, `INSERT INTO stages(id,tournament_id,kind,position,status) VALUES($1,$2,$3,$4,$5)`, s.Id, s.TournamentId, s.Kind, s.Position, s.Status); err != nil {
			return err
		}
	}
	for _, g := range p.Groups {
		if _, err := q.Exec(ctx, `INSERT INTO tournament_groups(id,stage_id,tournament_id,name) VALUES($1,$2,$3,$4)`, g.Id, g.StageId, p.TournamentId, g.Name); err != nil {
			return err
		}
		for _, id := range g.ApplicationIds {
			if _, err := q.Exec(ctx, `INSERT INTO group_participants(group_id,stage_id,tournament_id,application_id) VALUES($1,$2,$3,$4)`, g.Id, g.StageId, p.TournamentId, id); err != nil {
				return err
			}
		}
	}
	if err := saveMatches(ctx, q, p.Matches); err != nil {
		return err
	}
	t, err := readTournament(ctx, q, p.TournamentId, false)
	if err != nil {
		return err
	}
	for _, stage := range p.Stages {
		if stage.Kind != contract.StageKindPlayoffs {
			if err = rebuildStandings(ctx, q, t, stage.Id); err != nil {
				return err
			}
		}
	}
	return nil
}
func saveMatches(ctx context.Context, q DBTX, matches []contract.Match) error {
	for _, m := range matches {
		_, err := q.Exec(ctx, `INSERT INTO matches(id,tournament_id,stage_id,group_id,round,position,home_application_id,away_application_id,winner_application_id,next_match_id,next_match_slot,loser_next_match_id,loser_next_match_slot,status) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`, m.Id, m.TournamentId, m.StageId, m.GroupId, m.Round, m.Position, m.HomeApplicationId, m.AwayApplicationId, m.WinnerApplicationId, m.NextMatchId, m.NextMatchSlot, m.LoserNextMatchId, m.LoserNextMatchSlot, m.Status)
		if err != nil {
			return err
		}
	}
	return nil
}
