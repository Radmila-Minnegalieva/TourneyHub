package api

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"log/slog"
	"mime"
	"net"
	"net/mail"
	"net/smtp"
	"os"
	"strings"
	"time"
)

type mailMessage struct{ To, Subject, Text string }

func (a *API) runBackground(ctx context.Context) {
	if err := a.AutoConfirm(ctx); err != nil && ctx.Err() == nil {
		slog.Error("confirm expired results", "error", err)
	}
	if err := a.DeliverMail(ctx); err != nil && ctx.Err() == nil {
		slog.Error("deliver outbox", "error", err)
	}
	_, err := a.db.Exec(ctx, `DELETE FROM auth_rate_limits WHERE window_start<now()-interval '1 day'`)
	if err != nil && ctx.Err() == nil {
		slog.Error("expire rate limits", "error", err)
	}
	_, err = a.db.Exec(ctx, `DELETE FROM tournament_events WHERE created_at<now()-interval '7 days'`)
	if err != nil && ctx.Err() == nil {
		slog.Error("expire replay events", "error", err)
	}
}

// DeliverMail отправляет до 50 писем с блокировкой SKIP LOCKED для нескольких экземпляров.
// SMTP допускает доставку более одного раза при обрыве после DATA до commit.
func (a *API) DeliverMail(ctx context.Context) error {
	if os.Getenv("SMTP_ADDRESS") == "" {
		return nil
	}
	for i := 0; i < 50; i++ {
		done, err := a.deliverNextMail(ctx)
		if err != nil {
			return err
		}
		if done {
			return nil
		}
	}
	return nil
}

func (a *API) deliverNextMail(ctx context.Context) (bool, error) {
	tx, err := a.db.Begin(ctx)
	if err != nil {
		return false, err
	}
	defer tx.Rollback(context.WithoutCancel(ctx))
	var id int64
	var raw []byte
	rows, err := tx.Query(ctx, `SELECT id,payload FROM outbox_events WHERE topic='email' AND delivered_at IS NULL AND available_at<=now() ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED`)
	if err != nil {
		return false, err
	}
	if !rows.Next() {
		err = rows.Err()
		rows.Close()
		return true, err
	}
	if err := rows.Scan(&id, &raw); err != nil {
		rows.Close()
		return false, err
	}
	rows.Close()
	var message mailMessage
	if err := json.Unmarshal(raw, &message); err != nil {
		return false, err
	}
	sendErr := sendSMTP(ctx, message)
	if sendErr == nil {
		_, err = tx.Exec(ctx, `UPDATE outbox_events SET delivered_at=now(),payload='{"redacted":true}'::jsonb,attempts=attempts+1 WHERE id=$1`, id)
	} else {
		_, err = tx.Exec(ctx, `UPDATE outbox_events SET attempts=attempts+1,available_at=now()+make_interval(secs=>least(3600,30*power(2,least(attempts,7)))::int) WHERE id=$1`, id)
	}
	if err != nil {
		return false, err
	}
	if err := tx.Commit(ctx); err != nil {
		return false, err
	}
	if sendErr != nil {
		slog.Warn("SMTP delivery deferred", "outbox_id", id)
	}
	return false, nil
}

func sendSMTP(ctx context.Context, message mailMessage) error {
	address := os.Getenv("SMTP_ADDRESS")
	host, _, err := net.SplitHostPort(address)
	if err != nil {
		return fmt.Errorf("SMTP_ADDRESS: %w", err)
	}
	from := os.Getenv("SMTP_FROM")
	if from == "" {
		from = "noreply@tourneyhub.local"
	}
	if _, err := mail.ParseAddress(from); err != nil {
		return fmt.Errorf("SMTP_FROM: %w", err)
	}
	if _, err := mail.ParseAddress(message.To); err != nil {
		return fmt.Errorf("invalid recipient: %w", err)
	}
	if strings.ContainsAny(from+message.To+message.Subject, "\r\n") {
		return fmt.Errorf("invalid mail header")
	}
	dialer := net.Dialer{Timeout: 10 * time.Second}
	conn, err := dialer.DialContext(ctx, "tcp", address)
	if err != nil {
		return err
	}
	defer conn.Close()
	if err := conn.SetDeadline(time.Now().Add(15 * time.Second)); err != nil {
		return err
	}
	client, err := smtp.NewClient(conn, host)
	if err != nil {
		return err
	}
	defer client.Close()
	if ok, _ := client.Extension("STARTTLS"); ok {
		if err := client.StartTLS(&tls.Config{ServerName: host, MinVersion: tls.VersionTLS12}); err != nil {
			return err
		}
	} else if os.Getenv("SMTP_ALLOW_INSECURE") != "true" {
		return fmt.Errorf("SMTP requires STARTTLS; enable SMTP_ALLOW_INSECURE only for a local relay")
	}
	if user := os.Getenv("SMTP_USER"); user != "" {
		if err := client.Auth(smtp.PlainAuth("", user, os.Getenv("SMTP_PASSWORD"), host)); err != nil {
			return err
		}
	}
	if err := client.Mail(from); err != nil {
		return err
	}
	if err := client.Rcpt(message.To); err != nil {
		return err
	}
	w, err := client.Data()
	if err != nil {
		return err
	}
	_, err = fmt.Fprintf(w, "From: %s\r\nTo: %s\r\nSubject: %s\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n%s\r\n", from, message.To, mime.QEncoding.Encode("UTF-8", message.Subject), strings.ReplaceAll(strings.ReplaceAll(message.Text, "\r\n", "\n"), "\n", "\r\n"))
	if err != nil {
		return err
	}
	if err := w.Close(); err != nil {
		return err
	}
	return client.Quit()
}
