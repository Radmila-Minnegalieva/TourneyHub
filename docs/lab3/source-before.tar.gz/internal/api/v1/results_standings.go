package api

import (
	"context"
	"sort"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
)

type tableRow struct {
	contract.Standing
	group *uuid.UUID
	elo   float64
	mini  int
}

func standingsParticipants(ctx context.Context, q DBTX, t contract.Tournament, stageID uuid.UUID) ([]*tableRow, error) {
	rows, err := q.Query(ctx, `SELECT a.id,gp.group_id,coalesce(r.value,1500) FROM stages s JOIN applications a ON a.tournament_id=s.tournament_id AND a.status='accepted' LEFT JOIN group_participants gp ON gp.stage_id=s.id AND gp.application_id=a.id LEFT JOIN ratings r ON r.team_id=a.team_id AND r.discipline_id=$3 WHERE s.id=$1 AND s.tournament_id=$2 AND (s.kind='round_robin' OR gp.application_id IS NOT NULL) ORDER BY a.seed,a.id`, stageID, t.Id, t.DisciplineId)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := []*tableRow{}
	for rows.Next() {
		r := &tableRow{}
		if err = rows.Scan(&r.ApplicationId, &r.group, &r.elo); err != nil {
			return nil, err
		}
		result = append(result, r)
	}
	return result, rows.Err()
}
func updateStanding(r *tableRow, home, away int, rules contract.Rules) {
	r.Played++
	r.ScoreFor += home
	r.ScoreAgainst += away
	r.ScoreDifference = r.ScoreFor - r.ScoreAgainst
	switch {
	case home > away:
		r.Wins++
		r.Points += rules.WinPoints
	case home < away:
		r.Losses++
		r.Points += rules.LossPoints
	default:
		r.Draws++
		r.Points += rules.DrawPoints
	}
}
func headToHead(rows map[uuid.UUID]*tableRow, matches []contract.Match, rules contract.Rules) {
	for _, m := range matches {
		home, away := rows[*m.HomeApplicationId], rows[*m.AwayApplicationId]
		if home == nil || away == nil || home.Points != away.Points {
			continue
		}
		switch {
		case *m.HomeScore > *m.AwayScore:
			home.mini += rules.WinPoints
			away.mini += rules.LossPoints
		case *m.HomeScore < *m.AwayScore:
			away.mini += rules.WinPoints
			home.mini += rules.LossPoints
		default:
			home.mini += rules.DrawPoints
			away.mini += rules.DrawPoints
		}
	}
}
func standingLess(a, b *tableRow, breakers []contract.TieBreaker) bool {
	if a.Points != b.Points {
		return a.Points > b.Points
	}
	for _, breaker := range breakers {
		av, bv := 0.0, 0.0
		switch breaker {
		case contract.TieBreakerHeadToHead:
			av, bv = float64(a.mini), float64(b.mini)
		case contract.TieBreakerScoreDifference:
			av, bv = float64(a.ScoreDifference), float64(b.ScoreDifference)
		case contract.TieBreakerScoreFor:
			av, bv = float64(a.ScoreFor), float64(b.ScoreFor)
		case contract.TieBreakerElo:
			av, bv = a.elo, b.elo
		case contract.TieBreakerDraw:
			return a.ApplicationId.String() < b.ApplicationId.String()
		}
		if av != bv {
			return av > bv
		}
	}
	return a.ApplicationId.String() < b.ApplicationId.String()
}
func rebuildStandings(ctx context.Context, q DBTX, t contract.Tournament, stageID uuid.UUID) error {
	participants, err := standingsParticipants(ctx, q, t, stageID)
	if err != nil {
		return err
	}
	if len(participants) == 0 {
		return nil
	}
	rowsByID := map[uuid.UUID]*tableRow{}
	buckets := map[uuid.UUID][]*tableRow{}
	for _, row := range participants {
		rowsByID[row.ApplicationId] = row
		key := uuid.Nil
		if row.group != nil {
			key = *row.group
		}
		buckets[key] = append(buckets[key], row)
	}
	matches, err := matchList(ctx, q, `SELECT `+matchColumns+` FROM matches m WHERE m.stage_id=$1 AND m.status='completed' ORDER BY m.round,m.position`, stageID)
	if err != nil {
		return err
	}
	for _, m := range matches {
		home, away := rowsByID[*m.HomeApplicationId], rowsByID[*m.AwayApplicationId]
		if home == nil || away == nil {
			continue
		}
		updateStanding(home, *m.HomeScore, *m.AwayScore, t.Rules)
		updateStanding(away, *m.AwayScore, *m.HomeScore, t.Rules)
	}
	headToHead(rowsByID, matches, t.Rules)
	if _, err = q.Exec(ctx, `DELETE FROM standings WHERE stage_id=$1`, stageID); err != nil {
		return err
	}
	for _, bucket := range buckets {
		sort.Slice(bucket, func(i, j int) bool { return standingLess(bucket[i], bucket[j], t.Rules.TieBreakers) })
		for i, row := range bucket {
			row.Position = i + 1
			if err = writeStanding(ctx, q, t.Id, stageID, row); err != nil {
				return err
			}
		}
	}
	return event(ctx, q, t.Id, "standings_updated", map[string]any{"stage_id": stageID})
}
func writeStanding(ctx context.Context, q DBTX, tid, sid uuid.UUID, r *tableRow) error {
	_, err := q.Exec(ctx, `INSERT INTO standings(stage_id,tournament_id,group_id,application_id,position,played,wins,draws,losses,score_for,score_against,points) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, sid, tid, r.group, r.ApplicationId, r.Position, r.Played, r.Wins, r.Draws, r.Losses, r.ScoreFor, r.ScoreAgainst, r.Points)
	return err
}
func readStandings(ctx context.Context, q DBTX, tid uuid.UUID) ([]contract.Standings, error) {
	rows, err := q.Query(ctx, `SELECT s.stage_id,s.group_id,s.application_id,s.position,s.played,s.wins,s.draws,s.losses,s.score_for,s.score_against,s.points FROM standings s JOIN stages st ON st.id=s.stage_id LEFT JOIN tournament_groups g ON g.id=s.group_id WHERE s.tournament_id=$1 ORDER BY st.position,g.name NULLS FIRST,s.position,s.application_id`, tid)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := []contract.Standings{}
	for rows.Next() {
		var sid uuid.UUID
		var gid *uuid.UUID
		var r contract.Standing
		if err = rows.Scan(&sid, &gid, &r.ApplicationId, &r.Position, &r.Played, &r.Wins, &r.Draws, &r.Losses, &r.ScoreFor, &r.ScoreAgainst, &r.Points); err != nil {
			return nil, err
		}
		r.ScoreDifference = r.ScoreFor - r.ScoreAgainst
		if len(result) == 0 || result[len(result)-1].StageId != sid || !optionalUUIDEqual(result[len(result)-1].GroupId, gid) {
			result = append(result, contract.Standings{StageId: sid, GroupId: gid, Rows: []contract.Standing{}})
		}
		result[len(result)-1].Rows = append(result[len(result)-1].Rows, r)
	}
	return result, rows.Err()
}
func (a *API) GetStandings(c echo.Context, id uuid.UUID) error {
	ctx := c.Request().Context()
	if err := tournamentPublic(ctx, a.db, id); err != nil {
		return err
	}
	result, err := readStandings(ctx, a.db, id)
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}
