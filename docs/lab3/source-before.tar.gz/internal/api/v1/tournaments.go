package api

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"time"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

// tournamentJSON формирует публичное представление без персональных данных организатора.
const tournamentJSON = `jsonb_build_object(
 'id',t.id,'organizer',jsonb_build_object('id',u.id,'nickname',u.nickname,'name',u.name,
 'avatar_url',CASE WHEN u.avatar_file_id IS NOT NULL THEN '/api/v1/files/'||u.avatar_file_id END),
 'name',t.name,'description',t.description,'discipline_id',t.discipline_id,'format',t.format,
 'max_participants',t.max_participants,'registration_opens_at',t.registration_opens_at,
 'registration_closes_at',t.registration_closes_at,'starts_at',t.starts_at,'ends_at',t.ends_at,
 'timezone',t.timezone,'status',t.status,'hidden',t.hidden,'referee_id',t.referee_id,
 'accepted_count',(SELECT count(*) FROM applications WHERE tournament_id=t.id AND status='accepted'),
 'version',t.version,'created_at',t.created_at,'rules',jsonb_build_object(
 'best_of',t.best_of,'round_robin_legs',t.round_robin_legs,'win_points',t.win_points,
 'draw_points',t.draw_points,'loss_points',t.loss_points,'tie_breakers',t.tie_breakers,
 'third_place_match',t.third_place_match,'confirmation_timeout_hours',t.confirmation_timeout_hours,
 'group_settings',CASE WHEN t.group_count IS NOT NULL THEN jsonb_build_object(
 'group_count',t.group_count,'qualifiers_per_group',t.qualifiers_per_group,
 'wildcard_count',t.wildcard_count,'wildcard_place',t.wildcard_place) END))`

func readTournament(ctx context.Context, q DBTX, id uuid.UUID, lock bool) (contract.Tournament, error) {
	query := `SELECT ` + tournamentJSON + ` FROM tournaments t JOIN users u ON u.id=t.organizer_id WHERE t.id=$1 AND t.deleted_at IS NULL`
	if lock {
		query += ` FOR UPDATE OF t`
	}
	var raw []byte
	var tournament contract.Tournament
	if err := q.QueryRow(ctx, query, id).Scan(&raw); err != nil {
		return tournament, dbError(err)
	}
	err := json.Unmarshal(raw, &tournament)
	return tournament, err
}

func requireTournamentOwner(c echo.Context, t contract.Tournament) error {
	if hasRole(c, contract.Admin) || (hasRole(c, contract.Organizer) && currentUser(c) == t.Organizer.Id) {
		return nil
	}
	return forbidden("only the tournament organizer can perform this operation")
}

func tournamentPublic(ctx context.Context, q DBTX, id uuid.UUID) error {
	var exists bool
	err := q.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM tournaments WHERE id=$1 AND deleted_at IS NULL AND NOT hidden AND status<>'draft')`, id).Scan(&exists)
	if err != nil {
		return err
	}
	if !exists {
		return notFound("tournament not found")
	}
	return nil
}

func (a *API) ListTournaments(c echo.Context, p contract.ListTournamentsParams) error {
	return a.tournamentPage(c, p, nil, false)
}

func (a *API) ListMyTournaments(c echo.Context, p contract.ListMyTournamentsParams) error {
	id := currentUser(c)
	return a.tournamentPage(c, contract.ListTournamentsParams(p), &id, true)
}

func (a *API) tournamentPage(c echo.Context, p contract.ListTournamentsParams, owner *uuid.UUID, private bool) error {
	limit, offset := pagination(p.Limit, p.Offset)
	where := ` FROM tournaments t JOIN users u ON u.id=t.organizer_id
 WHERE t.deleted_at IS NULL AND ($1::uuid IS NULL OR t.organizer_id=$1)
 AND ($2 OR (NOT t.hidden AND t.status<>'draft'))
 AND ($3::uuid IS NULL OR t.discipline_id=$3) AND ($4::text IS NULL OR t.status=$4)
 AND ($5::text IS NULL OR t.format=$5) AND ($6::timestamptz IS NULL OR t.starts_at >= $6)
 AND ($7::timestamptz IS NULL OR t.starts_at <= $7) AND ($8::text IS NULL OR t.name ILIKE '%'||$8||'%')`
	args := []any{owner, private, p.DisciplineId, p.Status, p.Format, p.StartsFrom, p.StartsTo, p.Search}
	page := contract.TournamentPage{Items: []contract.Tournament{}, Limit: limit, Offset: offset}
	ctx := c.Request().Context()
	if err := a.db.QueryRow(ctx, `SELECT count(*)`+where, args...).Scan(&page.Total); err != nil {
		return dbError(err)
	}
	rows, err := a.db.Query(ctx, `SELECT `+tournamentJSON+where+` ORDER BY t.created_at DESC,t.id ASC LIMIT $9 OFFSET $10`, append(args, limit, offset)...)
	if err != nil {
		return dbError(err)
	}
	defer rows.Close()
	for rows.Next() {
		var raw []byte
		var item contract.Tournament
		if err := rows.Scan(&raw); err != nil {
			return err
		}
		if err := json.Unmarshal(raw, &item); err != nil {
			return err
		}
		page.Items = append(page.Items, item)
	}
	if err := rows.Err(); err != nil {
		return err
	}
	return c.JSON(http.StatusOK, page)
}

func (a *API) GetTournament(c echo.Context, id uuid.UUID) error {
	ctx := c.Request().Context()
	if err := tournamentPublic(ctx, a.db, id); err != nil {
		return err
	}
	t, err := readTournament(ctx, a.db, id, false)
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, t)
}

func validateTournamentRequest(r contract.CreateTournamentRequest, publishing bool) error {
	if strings.TrimSpace(r.Name) == "" || !r.Format.Valid() || r.MaxParticipants < 2 || r.MaxParticipants > 256 {
		return invalid("invalid tournament name, format or participant limit")
	}
	if r.Timezone == "" || r.Timezone == "Local" {
		return invalid("timezone must be an IANA identifier")
	}
	if _, err := time.LoadLocation(r.Timezone); err != nil {
		return invalid("timezone must be an IANA identifier")
	}
	if err := validateTournamentDates(r, publishing); err != nil {
		return err
	}
	return validateTournamentRules(r.Format, r.MaxParticipants, r.Rules)
}

func validateTournamentDates(r contract.CreateTournamentRequest, required bool) error {
	dates := []*time.Time{r.RegistrationOpensAt, r.RegistrationClosesAt, r.StartsAt, r.EndsAt}
	for _, date := range dates {
		if required && date == nil {
			return invalid("publication requires registration and tournament dates")
		}
	}
	for i := 1; i < len(dates); i++ {
		previous, next := dates[i-1], dates[i]
		if previous == nil || next == nil {
			continue
		}
		if previous.After(*next) || (i != 2 && previous.Equal(*next)) {
			return invalid("dates must satisfy opens < closes <= starts < ends")
		}
	}
	return nil
}

func validateTournamentRules(format contract.TournamentFormat, max int, r contract.Rules) error {
	if !r.BestOf.Valid() || !r.RoundRobinLegs.Valid() || len(r.TieBreakers) == 0 || r.ConfirmationTimeoutHours < 1 || r.ConfirmationTimeoutHours > 168 {
		return invalid("invalid tournament rules")
	}
	for _, points := range []int{r.WinPoints, r.DrawPoints, r.LossPoints} {
		if points < 0 || points > 100 {
			return invalid("points must be between 0 and 100")
		}
	}
	seen := make(map[contract.TieBreaker]bool)
	for _, tie := range r.TieBreakers {
		if !tie.Valid() || seen[tie] {
			return invalid("tie breakers must be valid and unique")
		}
		seen[tie] = true
	}
	if format == contract.TournamentFormatRoundRobin && r.ThirdPlaceMatch {
		return invalid("a round robin has no third place match")
	}
	if err := validateGroupSettings(format, max, r.GroupSettings); err != nil {
		return err
	}
	if r.ThirdPlaceMatch {
		count := max
		if r.GroupSettings != nil {
			g := r.GroupSettings
			count = g.GroupCount*g.QualifiersPerGroup + g.WildcardCount
		}
		if count < 4 {
			return invalid("third-place match needs at least four playoff participants")
		}
	}
	return nil
}

func validateGroupSettings(format contract.TournamentFormat, max int, g *contract.GroupSettings) error {
	if format != contract.TournamentFormatGroupsPlayoffs {
		if g != nil {
			return invalid("group settings apply only to groups_playoffs")
		}
		return nil
	}
	if g == nil || g.GroupCount < 2 || g.GroupCount > 64 || g.QualifiersPerGroup < 1 || g.QualifiersPerGroup > 128 {
		return invalid("groups_playoffs requires valid group settings")
	}
	if g.GroupCount*2 > max || g.GroupCount*g.QualifiersPerGroup+g.WildcardCount > max || g.WildcardCount < 0 || g.WildcardCount > g.GroupCount {
		return invalid("group configuration exceeds the participant limit")
	}
	if g.WildcardCount > 0 && (g.WildcardPlace == nil || *g.WildcardPlace <= g.QualifiersPerGroup || *g.WildcardPlace > max/g.GroupCount) {
		return invalid("wildcard place must follow automatic qualifying places and exist in each group")
	}
	return nil
}

type rosterRules struct {
	Min, Max int
	Draw     bool
	Unit     string
}

func readDisciplineRules(ctx context.Context, q DBTX, id uuid.UUID) (rosterRules, error) {
	var r rosterRules
	err := q.QueryRow(ctx, `SELECT min_roster_size,max_roster_size,allows_draw,score_unit FROM disciplines WHERE id=$1 AND active`, id).Scan(&r.Min, &r.Max, &r.Draw, &r.Unit)
	return r, dbError(err)
}

func tournamentRuleArgs(r contract.Rules) []any {
	var count, qualifiers, wildcardPlace *int
	wildcard := 0
	if g := r.GroupSettings; g != nil {
		count, qualifiers, wildcardPlace, wildcard = &g.GroupCount, &g.QualifiersPerGroup, g.WildcardPlace, g.WildcardCount
	}
	ties := make([]string, len(r.TieBreakers))
	for i, tie := range r.TieBreakers {
		ties[i] = string(tie)
	}
	return []any{r.BestOf, r.RoundRobinLegs, r.WinPoints, r.DrawPoints, r.LossPoints, ties, r.ThirdPlaceMatch, r.ConfirmationTimeoutHours, count, qualifiers, wildcard, wildcardPlace}
}

func (a *API) CreateTournament(c echo.Context) error {
	if err := requireRole(c, contract.Organizer); err != nil {
		return err
	}
	var r contract.CreateTournamentRequest
	if err := bindJSON(c, &r); err != nil {
		return err
	}
	if err := validateTournamentRequest(r, false); err != nil {
		return err
	}
	var result contract.Tournament
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		roster, err := readDisciplineRules(ctx, tx, r.DisciplineId)
		if err != nil {
			return err
		}
		id := uuid.New()
		args := []any{id, currentUser(c), r.DisciplineId, strings.TrimSpace(r.Name), r.Description, r.Format, r.MaxParticipants, r.RegistrationOpensAt, r.RegistrationClosesAt, r.StartsAt, r.EndsAt, r.Timezone}
		args = append(args, tournamentRuleArgs(r.Rules)...)
		args = append(args, roster.Min, roster.Max, roster.Draw, roster.Unit)
		_, err = tx.Exec(ctx, `INSERT INTO tournaments(id,organizer_id,discipline_id,name,description,format,max_participants,registration_opens_at,registration_closes_at,starts_at,ends_at,timezone,best_of,round_robin_legs,win_points,draw_points,loss_points,tie_breakers,third_place_match,confirmation_timeout_hours,group_count,qualifiers_per_group,wildcard_count,wildcard_place,min_roster_size,max_roster_size,allows_draw,score_unit)
 VALUES($1,$2,$3,$4,COALESCE($5,''),$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28)`, args...)
		if err != nil {
			return dbError(err)
		}
		result, err = readTournament(ctx, tx, id, false)
		if err != nil {
			return err
		}
		return audit(ctx, tx, currentUser(c), "tournament_created", "tournament", id, nil, result)
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusCreated, result)
}

func tournamentRequest(t contract.Tournament) contract.CreateTournamentRequest {
	return contract.CreateTournamentRequest{Name: t.Name, Description: t.Description, DisciplineId: t.DisciplineId, Format: t.Format, MaxParticipants: t.MaxParticipants, Timezone: t.Timezone, Rules: t.Rules, RegistrationOpensAt: t.RegistrationOpensAt, RegistrationClosesAt: t.RegistrationClosesAt, StartsAt: t.StartsAt, EndsAt: t.EndsAt}
}

func replacePresent[T any](dst *T, src *T) {
	if src != nil {
		*dst = *src
	}
}

func replacePresentPointer[T any](dst **T, src *T) {
	if src != nil {
		*dst = src
	}
}

func mergeTournament(t contract.Tournament, p contract.UpdateTournamentRequest) contract.CreateTournamentRequest {
	r := tournamentRequest(t)
	replacePresent(&r.Name, p.Name)
	replacePresent(&r.DisciplineId, p.DisciplineId)
	replacePresent(&r.Format, p.Format)
	replacePresent(&r.MaxParticipants, p.MaxParticipants)
	replacePresent(&r.Timezone, p.Timezone)
	replacePresent(&r.Rules, p.Rules)
	replacePresentPointer(&r.Description, p.Description)
	replacePresentPointer(&r.RegistrationOpensAt, p.RegistrationOpensAt)
	replacePresentPointer(&r.RegistrationClosesAt, p.RegistrationClosesAt)
	replacePresentPointer(&r.StartsAt, p.StartsAt)
	replacePresentPointer(&r.EndsAt, p.EndsAt)
	return r
}

func (a *API) UpdateTournament(c echo.Context, id uuid.UUID) error {
	var p contract.UpdateTournamentRequest
	if err := bindJSON(c, &p); err != nil {
		return err
	}
	return a.mutateTournament(c, id, p.Version, "tournament_updated", func(ctx context.Context, tx pgx.Tx, before contract.Tournament) error {
		if before.Status != contract.TournamentStatusDraft && before.Status != contract.TournamentStatusRegistration {
			return conflict("only a draft or registration tournament can be edited")
		}
		r := mergeTournament(before, p)
		if err := validateTournamentRequest(r, before.Status == contract.TournamentStatusRegistration); err != nil {
			return err
		}
		if r.MaxParticipants < before.AcceptedCount {
			return conflict("participant limit is below the accepted participant count")
		}
		return updateTournamentFields(ctx, tx, id, r, r.DisciplineId != before.DisciplineId)
	})
}

func updateTournamentFields(ctx context.Context, tx pgx.Tx, id uuid.UUID, r contract.CreateTournamentRequest, refreshDiscipline bool) error {
	var roster rosterRules
	var err error
	if refreshDiscipline {
		roster, err = readDisciplineRules(ctx, tx, r.DisciplineId)
	} else {
		err = tx.QueryRow(ctx, `SELECT min_roster_size,max_roster_size,allows_draw,score_unit FROM tournaments WHERE id=$1`, id).Scan(&roster.Min, &roster.Max, &roster.Draw, &roster.Unit)
	}
	if err != nil {
		return err
	}
	var incompatible bool
	err = tx.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM applications a WHERE a.tournament_id=$1 AND a.status IN ('pending','accepted') AND (SELECT count(*) FROM application_players p WHERE p.application_id=a.id) NOT BETWEEN $2 AND $3)`, id, roster.Min, roster.Max).Scan(&incompatible)
	if err != nil {
		return err
	}
	if incompatible {
		return conflict("existing application rosters do not match the new discipline")
	}
	args := []any{id, r.DisciplineId, strings.TrimSpace(r.Name), r.Description, r.Format, r.MaxParticipants, r.RegistrationOpensAt, r.RegistrationClosesAt, r.StartsAt, r.EndsAt, r.Timezone}
	args = append(args, tournamentRuleArgs(r.Rules)...)
	args = append(args, roster.Min, roster.Max, roster.Draw, roster.Unit)
	_, err = tx.Exec(ctx, `UPDATE tournaments SET discipline_id=$2,name=$3,description=COALESCE($4,''),format=$5,max_participants=$6,registration_opens_at=$7,registration_closes_at=$8,starts_at=$9,ends_at=$10,timezone=$11,best_of=$12,round_robin_legs=$13,win_points=$14,draw_points=$15,loss_points=$16,tie_breakers=$17,third_place_match=$18,confirmation_timeout_hours=$19,group_count=$20,qualifiers_per_group=$21,wildcard_count=$22,wildcard_place=$23,min_roster_size=$24,max_roster_size=$25,allows_draw=$26,score_unit=$27 WHERE id=$1`, args...)
	return dbError(err)
}

func (a *API) mutateTournament(c echo.Context, id uuid.UUID, version int, action string, mutate func(context.Context, pgx.Tx, contract.Tournament) error) error {
	var result contract.Tournament
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		before, err := readTournament(ctx, tx, id, true)
		if err != nil {
			return err
		}
		if err := requireTournamentOwner(c, before); err != nil {
			return err
		}
		if before.Version != version {
			return conflict("tournament version is stale")
		}
		if err := mutate(ctx, tx, before); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE tournaments SET version=version+1,updated_at=now() WHERE id=$1`, id); err != nil {
			return err
		}
		result, err = readTournament(ctx, tx, id, false)
		if err != nil {
			return err
		}
		if err := audit(ctx, tx, currentUser(c), action, "tournament", id, before, result); err != nil {
			return err
		}
		return event(ctx, tx, id, "tournament_updated", result)
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, result)
}

func (a *API) PublishTournament(c echo.Context, id uuid.UUID) error {
	var r contract.VersionRequest
	if err := bindJSON(c, &r); err != nil {
		return err
	}
	return a.mutateTournament(c, id, r.Version, "tournament_published", func(ctx context.Context, tx pgx.Tx, t contract.Tournament) error {
		if t.Status != contract.TournamentStatusDraft {
			return conflict("only a draft can be published")
		}
		if err := validateTournamentRequest(tournamentRequest(t), true); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `UPDATE tournaments SET status='registration' WHERE id=$1`, id)
		return err
	})
}

func (a *API) CancelTournament(c echo.Context, id uuid.UUID) error {
	var r contract.ReasonRequest
	if err := bindJSON(c, &r); err != nil {
		return err
	}
	if strings.TrimSpace(r.Reason) == "" {
		return invalid("cancellation reason is required")
	}
	return a.mutateTournament(c, id, r.Version, "tournament_cancelled", func(ctx context.Context, tx pgx.Tx, t contract.Tournament) error {
		if t.Status == contract.TournamentStatusCompleted || t.Status == contract.TournamentStatusCancelled {
			return conflict("the tournament cannot be cancelled in its current state")
		}
		if _, err := tx.Exec(ctx, `UPDATE tournaments SET status='cancelled' WHERE id=$1`, id); err != nil {
			return err
		}
		return notifyTournamentPlayers(ctx, tx, id, "tournament_cancelled", r.Reason)
	})
}

func notifyTournamentPlayers(ctx context.Context, q DBTX, id uuid.UUID, kind, message string) error {
	rows, err := q.Query(ctx, `SELECT DISTINCT ap.user_id FROM application_players ap JOIN applications a ON a.id=ap.application_id WHERE ap.tournament_id=$1 AND a.status IN ('pending','accepted') ORDER BY ap.user_id`, id)
	if err != nil {
		return err
	}
	users, err := pgx.CollectRows(rows, pgx.RowTo[uuid.UUID])
	if err != nil {
		return err
	}
	for _, user := range users {
		if err := notify(ctx, q, user, kind, message, id); err != nil {
			return err
		}
	}
	return nil
}

func (a *API) CompleteTournament(c echo.Context, id uuid.UUID) error {
	var r contract.VersionRequest
	if err := bindJSON(c, &r); err != nil {
		return err
	}
	return a.mutateTournament(c, id, r.Version, "tournament_completed", func(ctx context.Context, tx pgx.Tx, t contract.Tournament) error {
		if t.Status != contract.TournamentStatusInProgress {
			return conflict("only an active tournament can be completed")
		}
		return finalizeTournament(ctx, tx, id)
	})
}

func (a *API) AssignTournamentReferee(c echo.Context, id uuid.UUID) error {
	var r contract.AssignRefereeRequest
	if err := bindJSON(c, &r); err != nil {
		return err
	}
	return a.mutateTournament(c, id, r.Version, "tournament_referee_assigned", func(ctx context.Context, tx pgx.Tx, t contract.Tournament) error {
		if t.Status == contract.TournamentStatusCancelled || t.Status == contract.TournamentStatusCompleted {
			return conflict("the tournament is no longer active")
		}
		if err := scheduleLock(ctx, tx); err != nil {
			return err
		}
		if err := validateReferee(ctx, tx, r.RefereeId); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `UPDATE tournaments SET referee_id=$2 WHERE id=$1`, id, r.RefereeId)
		if err != nil {
			return err
		}
		t.RefereeId = &r.RefereeId
		if err := validateTournamentRefereeSchedule(ctx, tx, t); err != nil {
			return err
		}
		return notify(ctx, tx, r.RefereeId, "referee_assigned", "You have been assigned as tournament referee", id)
	})
}

func validateTournamentRefereeSchedule(ctx context.Context, tx pgx.Tx, t contract.Tournament) error {
	matches, err := matchList(ctx, tx, `SELECT `+matchColumns+` FROM matches m WHERE m.tournament_id=$1 AND m.referee_id IS NULL AND m.starts_at IS NOT NULL AND m.status NOT IN ('completed','bye') ORDER BY m.id`, t.Id)
	if err != nil {
		return err
	}
	for _, match := range matches {
		if err := scheduleConflict(ctx, tx, t, match, *match.StartsAt); err != nil {
			return err
		}
	}
	return nil
}
