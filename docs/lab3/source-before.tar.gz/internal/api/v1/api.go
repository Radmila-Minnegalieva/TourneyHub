// Package api реализует HTTP API TourneyHub поверх PostgreSQL.
package api

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"time"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/labstack/echo/v4"
)

// DBTX позволяет выполнять одинаковые запросы через пул и внутри транзакции.
type DBTX interface {
	Exec(context.Context, string, ...any) (pgconn.CommandTag, error)
	Query(context.Context, string, ...any) (pgx.Rows, error)
	QueryRow(context.Context, string, ...any) pgx.Row
}

// API содержит зависимости обработчиков. Состояние пользователей хранится в БД.
type API struct{ db *pgxpool.Pool }

var _ contract.ServerInterface = (*API)(nil)

// New создаёт API. Без пула доступны health checks и валидация контракта.
func New(db ...*pgxpool.Pool) *API {
	a := &API{}
	if len(db) > 0 {
		a.db = db[0]
	}
	return a
}

// Principal содержит проверенную учётную запись текущего запроса.
type Principal struct {
	ID    uuid.UUID
	Roles []contract.Role
}

func principal(c echo.Context) Principal   { p, _ := c.Get("principal").(Principal); return p }
func currentUser(c echo.Context) uuid.UUID { return principal(c).ID }
func hasRole(c echo.Context, roles ...contract.Role) bool {
	for _, actual := range principal(c).Roles {
		if actual == contract.Admin {
			return true
		}
		for _, role := range roles {
			if actual == role {
				return true
			}
		}
	}
	return false
}
func requireRole(c echo.Context, roles ...contract.Role) error {
	if currentUser(c) == uuid.Nil {
		return echo.NewHTTPError(http.StatusUnauthorized, "authentication required")
	}
	if !hasRole(c, roles...) {
		return forbidden("insufficient role")
	}
	return nil
}
func invalid(message string) error   { return echo.NewHTTPError(http.StatusUnprocessableEntity, message) }
func conflict(message string) error  { return echo.NewHTTPError(http.StatusConflict, message) }
func notFound(message string) error  { return echo.NewHTTPError(http.StatusNotFound, message) }
func forbidden(message string) error { return echo.NewHTTPError(http.StatusForbidden, message) }

func bindJSON(c echo.Context, dst any) error {
	decoder := json.NewDecoder(c.Request().Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(dst); err != nil {
		return echo.NewHTTPError(400, "invalid JSON body").SetInternal(err)
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		return echo.NewHTTPError(400, "expected one JSON object")
	}
	return nil
}

func dbError(err error) error {
	if err == nil {
		return nil
	}
	if errors.Is(err, pgx.ErrNoRows) {
		return notFound("resource not found")
	}
	var p *pgconn.PgError
	if errors.As(err, &p) {
		switch p.Code {
		case "23505":
			return conflict("resource already exists or player is already registered")
		case "23503", "23514", "23502", "22P02":
			return invalid("invalid resource reference or value")
		case "40001", "40P01":
			return conflict("concurrent modification; retry with current version")
		}
	}
	return err
}

func (a *API) withTx(c echo.Context, fn func(pgx.Tx) error) error {
	if a.db == nil {
		return echo.NewHTTPError(503, "database unavailable")
	}
	ctx := c.Request().Context()
	tx, err := a.db.Begin(ctx)
	if err != nil {
		return dbError(err)
	}
	defer tx.Rollback(context.WithoutCancel(ctx))
	if err := fn(tx); err != nil {
		return dbError(err)
	}
	return dbError(tx.Commit(ctx))
}

func pagination(limit, offset *int) (int, int) {
	l, o := 20, 0
	if limit != nil {
		l = *limit
	}
	if offset != nil {
		o = *offset
	}
	return l, o
}

func audit(ctx context.Context, q DBTX, actor uuid.UUID, action, entityType string, entityID uuid.UUID, before, after any) error {
	var actorID *uuid.UUID
	if actor != uuid.Nil {
		actorID = &actor
	}
	_, err := q.Exec(ctx, `INSERT INTO audit_entries(actor_id,action,entity_type,entity_id,before,after) VALUES($1,$2,$3,$4,$5,$6)`, actorID, action, entityType, entityID, before, after)
	return err
}

func outbox(ctx context.Context, q DBTX, topic string, aggregateID uuid.UUID, payload any) error {
	_, err := q.Exec(ctx, `INSERT INTO outbox_events(topic,aggregate_id,payload) VALUES($1,$2,$3)`, topic, aggregateID, payload)
	return err
}

func notify(ctx context.Context, q DBTX, userID uuid.UUID, kind, message string, resourceID uuid.UUID) error {
	_, err := q.Exec(ctx, `INSERT INTO notifications(user_id,kind,message,resource_id) VALUES($1,$2,$3,$4)`, userID, kind, message, resourceID)
	if err != nil {
		return err
	}
	var email string
	var enabled bool
	if err := q.QueryRow(ctx, `SELECT email,email_notifications AND blocked_at IS NULL FROM users WHERE id=$1`, userID).Scan(&email, &enabled); err != nil {
		return err
	}
	if enabled {
		return outbox(ctx, q, "email", resourceID, map[string]any{"to": email, "subject": "TourneyHub: " + kind, "text": message})
	}
	return nil
}

func event(ctx context.Context, q DBTX, tournamentID uuid.UUID, kind string, payload any) error {
	_, err := q.Exec(ctx, `INSERT INTO tournament_events(tournament_id,kind,payload) VALUES($1,$2,$3)`, tournamentID, kind, payload)
	return err
}

// Background обрабатывает просроченные результаты и надёжную очередь почты.
func (a *API) Background(ctx context.Context) {
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()
	for {
		a.runBackground(ctx)
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
	}
}
