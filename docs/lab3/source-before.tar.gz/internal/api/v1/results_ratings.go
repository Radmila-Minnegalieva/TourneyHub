package api

import (
	"context"
	"math"

	"github.com/Radmila-Minnegalieva/TourneyHub/backend/internal/model"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
)

type ratingMatch struct {
	id, tournament, home, away uuid.UUID
	homeScore, awayScore       int
}
type ratingValue struct {
	value  float64
	played int
}

// Рейтинг воспроизводится в порядке первоначальной фиксации матчей. Исправление
// старого результата пересчитывает последующие матчи, сохраняя прежние ревизии.
func rebuildRatings(ctx context.Context, tx pgx.Tx, discipline uuid.UUID) error {
	if _, err := tx.Exec(ctx, `SELECT pg_advisory_xact_lock(hashtextextended($1::text,913))`, discipline.String()); err != nil {
		return err
	}
	matches, err := ratedMatches(ctx, tx, discipline)
	if err != nil {
		return err
	}
	values := map[uuid.UUID]ratingValue{}
	for _, m := range matches {
		home, away := values[m.home], values[m.away]
		if home.played == 0 {
			home.value = model.InitialRating
		}
		if away.played == 0 {
			away.value = model.InitialRating
		}
		score := 0.5
		if m.homeScore > m.awayScore {
			score = 1
		} else if m.homeScore < m.awayScore {
			score = 0
		}
		before := model.EloRating{Value: home.value}
		change, err := before.AfterMatch(away.value, score)
		if err != nil {
			return err
		}
		if err = saveRatingChange(ctx, tx, discipline, m, m.home, home.value, change.Delta, home.played+1); err != nil {
			return err
		}
		if err = saveRatingChange(ctx, tx, discipline, m, m.away, away.value, -change.Delta, away.played+1); err != nil {
			return err
		}
		values[m.home] = ratingValue{home.value + change.Delta, home.played + 1}
		values[m.away] = ratingValue{away.value - change.Delta, away.played + 1}
	}
	return nil
}
func ratedMatches(ctx context.Context, q DBTX, discipline uuid.UUID) ([]ratingMatch, error) {
	rows, err := q.Query(ctx, `SELECT m.id,m.tournament_id,ha.team_id,aa.team_id,m.home_score,m.away_score FROM matches m JOIN tournaments t ON t.id=m.tournament_id JOIN applications ha ON ha.id=m.home_application_id JOIN applications aa ON aa.id=m.away_application_id WHERE t.discipline_id=$1 AND m.final_report_id IS NOT NULL ORDER BY (SELECT min(r.confirmed_at) FROM result_reports r WHERE r.match_id=m.id),m.id`, discipline)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := []ratingMatch{}
	for rows.Next() {
		var m ratingMatch
		if err = rows.Scan(&m.id, &m.tournament, &m.home, &m.away, &m.homeScore, &m.awayScore); err != nil {
			return nil, err
		}
		result = append(result, m)
	}
	return result, rows.Err()
}
func saveRatingChange(ctx context.Context, q DBTX, discipline uuid.UUID, m ratingMatch, team uuid.UUID, before, delta float64, played int) error {
	if _, err := q.Exec(ctx, `INSERT INTO ratings(team_id,discipline_id,value,played) VALUES($1,$2,$3,$4) ON CONFLICT(team_id,discipline_id) DO UPDATE SET value=excluded.value,played=excluded.played,version=ratings.version+1`, team, discipline, before+delta, played); err != nil {
		return err
	}
	var oldBefore, oldDelta float64
	var revision int
	err := q.QueryRow(ctx, `SELECT before,delta,revision FROM rating_changes WHERE match_id=$1 AND team_id=$2 ORDER BY revision DESC LIMIT 1`, m.id, team).Scan(&oldBefore, &oldDelta, &revision)
	if err != nil && !ignoreNoRows(err) {
		return err
	}
	if err == nil && math.Abs(before-oldBefore) < 1e-9 && math.Abs(delta-oldDelta) < 1e-9 {
		return nil
	}
	_, err = q.Exec(ctx, `INSERT INTO rating_changes(match_id,tournament_id,team_id,discipline_id,before,delta,after,revision) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`, m.id, m.tournament, team, discipline, before, delta, before+delta, revision+1)
	return err
}

func recordMatchRating(ctx context.Context, tx pgx.Tx, tournament, discipline uuid.UUID, m ratingMatch, correction bool) error {
	if correction {
		return rebuildRatings(ctx, tx, discipline)
	}
	if _, err := tx.Exec(ctx, `SELECT pg_advisory_xact_lock(hashtextextended($1::text,913))`, discipline.String()); err != nil {
		return err
	}
	if err := tx.QueryRow(ctx, `SELECT ha.team_id,aa.team_id FROM matches m JOIN applications ha ON ha.id=m.home_application_id JOIN applications aa ON aa.id=m.away_application_id WHERE m.id=$1`, m.id).Scan(&m.home, &m.away); err != nil {
		return err
	}
	m.tournament = tournament
	home, err := currentRating(ctx, tx, m.home, discipline)
	if err != nil {
		return err
	}
	away, err := currentRating(ctx, tx, m.away, discipline)
	if err != nil {
		return err
	}
	score := 0.5
	if m.homeScore > m.awayScore {
		score = 1
	} else if m.homeScore < m.awayScore {
		score = 0
	}
	rating := model.EloRating{Value: home.value}
	change, err := rating.AfterMatch(away.value, score)
	if err != nil {
		return err
	}
	if err = saveRatingChange(ctx, tx, discipline, m, m.home, home.value, change.Delta, home.played+1); err != nil {
		return err
	}
	return saveRatingChange(ctx, tx, discipline, m, m.away, away.value, -change.Delta, away.played+1)
}
func currentRating(ctx context.Context, q DBTX, team, discipline uuid.UUID) (ratingValue, error) {
	result := ratingValue{value: model.InitialRating}
	err := q.QueryRow(ctx, `SELECT value,played FROM ratings WHERE team_id=$1 AND discipline_id=$2`, team, discipline).Scan(&result.value, &result.played)
	if ignoreNoRows(err) {
		return result, nil
	}
	return result, err
}
