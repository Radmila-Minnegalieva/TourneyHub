package api

import (
	"context"
	"errors"
	"net/http"
	"time"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

const matchColumns = `m.id,m.tournament_id,m.stage_id,m.group_id,m.round,m.position,m.home_application_id,m.away_application_id,m.winner_application_id,m.next_match_id,m.next_match_slot,m.loser_next_match_id,m.loser_next_match_slot,m.starts_at,m.venue,m.online_url,m.referee_id,m.status,m.home_score,m.away_score,m.version`

func scanMatch(row pgx.Row) (contract.Match, error) {
	var m contract.Match
	err := row.Scan(&m.Id, &m.TournamentId, &m.StageId, &m.GroupId, &m.Round, &m.Position, &m.HomeApplicationId, &m.AwayApplicationId, &m.WinnerApplicationId, &m.NextMatchId, &m.NextMatchSlot, &m.LoserNextMatchId, &m.LoserNextMatchSlot, &m.StartsAt, &m.Venue, &m.OnlineUrl, &m.RefereeId, &m.Status, &m.HomeScore, &m.AwayScore, &m.Version)
	return m, dbError(err)
}
func readMatch(ctx context.Context, q DBTX, id uuid.UUID, lock bool) (contract.Match, error) {
	sql := `SELECT ` + matchColumns + ` FROM matches m WHERE m.id=$1`
	if lock {
		sql += ` FOR UPDATE`
	}
	return scanMatch(q.QueryRow(ctx, sql, id))
}
func matchList(ctx context.Context, q DBTX, query string, args ...any) ([]contract.Match, error) {
	rows, err := q.Query(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]contract.Match, 0)
	for rows.Next() {
		m, e := scanMatch(rows)
		if e != nil {
			return nil, e
		}
		items = append(items, m)
	}
	return items, rows.Err()
}
func (a *API) matchTransaction(c echo.Context, id uuid.UUID, fn func(pgx.Tx, contract.Tournament, contract.Match) error) error {
	ctx := c.Request().Context()
	var tournamentID uuid.UUID
	if err := a.db.QueryRow(ctx, `SELECT tournament_id FROM matches WHERE id=$1`, id).Scan(&tournamentID); err != nil {
		return dbError(err)
	}
	return a.withTx(c, func(tx pgx.Tx) error {
		t, err := readTournament(ctx, tx, tournamentID, true)
		if err != nil {
			return err
		}
		m, err := readMatch(ctx, tx, id, true)
		if err != nil {
			return err
		}
		return fn(tx, t, m)
	})
}
func matchVersion(m contract.Match, version int) error {
	if m.Version != version {
		return conflict("match version is stale")
	}
	return nil
}
func tournamentPlaying(t contract.Tournament) error {
	if t.Status != contract.TournamentStatusInProgress {
		return conflict("tournament is not in progress")
	}
	return nil
}
func (a *API) GetMatch(c echo.Context, id uuid.UUID) error {
	m, err := readMatch(c.Request().Context(), a.db, id, false)
	if err != nil {
		return err
	}
	if err = tournamentPublic(c.Request().Context(), a.db, m.TournamentId); err != nil {
		return err
	}
	return c.JSON(http.StatusOK, m)
}
func (a *API) ListMatches(c echo.Context, id uuid.UUID, p contract.ListMatchesParams) error {
	ctx := c.Request().Context()
	if err := tournamentPublic(ctx, a.db, id); err != nil {
		return err
	}
	limit, offset := pagination(p.Limit, p.Offset)
	filter := ` FROM matches m WHERE m.tournament_id=$1 AND ($2::uuid IS NULL OR m.stage_id=$2) AND ($3::uuid IS NULL OR m.group_id=$3) AND ($4::int IS NULL OR m.round=$4) AND ($5::text IS NULL OR m.status=$5)`
	args := []any{id, p.StageId, p.GroupId, p.Round, p.Status}
	var total int
	if err := a.db.QueryRow(ctx, `SELECT count(*)`+filter, args...).Scan(&total); err != nil {
		return err
	}
	args = append(args, limit, offset)
	items, err := matchList(ctx, a.db, `SELECT `+matchColumns+filter+` ORDER BY m.starts_at NULLS LAST,m.stage_id,m.round,m.position,m.id LIMIT $6 OFFSET $7`, args...)
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, contract.MatchPage{Items: items, Total: total, Limit: limit, Offset: offset})
}
func readBracket(ctx context.Context, q DBTX, id uuid.UUID) (contract.Bracket, error) {
	result := contract.Bracket{Stages: []contract.Stage{}, Groups: []contract.Group{}, Matches: []contract.Match{}}
	rows, err := q.Query(ctx, `SELECT id,tournament_id,kind,position,status FROM stages WHERE tournament_id=$1 ORDER BY position`, id)
	if err != nil {
		return result, err
	}
	for rows.Next() {
		var s contract.Stage
		if err = rows.Scan(&s.Id, &s.TournamentId, &s.Kind, &s.Position, &s.Status); err != nil {
			rows.Close()
			return result, err
		}
		result.Stages = append(result.Stages, s)
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return result, err
	}
	rows, err = q.Query(ctx, `SELECT g.id,g.stage_id,g.name,coalesce(array_agg(p.application_id ORDER BY a.seed) FILTER(WHERE p.application_id IS NOT NULL),'{}'::uuid[]) FROM tournament_groups g LEFT JOIN group_participants p ON p.group_id=g.id LEFT JOIN applications a ON a.id=p.application_id WHERE g.tournament_id=$1 GROUP BY g.id ORDER BY g.name,g.id`, id)
	if err != nil {
		return result, err
	}
	for rows.Next() {
		var g contract.Group
		if err = rows.Scan(&g.Id, &g.StageId, &g.Name, &g.ApplicationIds); err != nil {
			rows.Close()
			return result, err
		}
		result.Groups = append(result.Groups, g)
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return result, err
	}
	result.Matches, err = matchList(ctx, q, `SELECT `+matchColumns+` FROM matches m JOIN stages s ON s.id=m.stage_id WHERE m.tournament_id=$1 ORDER BY s.position,m.round,m.position`, id)
	return result, err
}
func (a *API) GetBracket(c echo.Context, id uuid.UUID) error {
	ctx := c.Request().Context()
	if err := tournamentPublic(ctx, a.db, id); err != nil {
		return err
	}
	b, err := readBracket(ctx, a.db, id)
	if err != nil {
		return err
	}
	return c.JSON(200, b)
}
func matchCaptain(ctx context.Context, q DBTX, m contract.Match, user uuid.UUID) (int, error) {
	var side int
	err := q.QueryRow(ctx, `SELECT CASE WHEN EXISTS(SELECT 1 FROM applications a JOIN teams t ON t.id=a.team_id WHERE a.id=$1 AND t.captain_id=$3) THEN 1 WHEN EXISTS(SELECT 1 FROM applications a JOIN teams t ON t.id=a.team_id WHERE a.id=$2 AND t.captain_id=$3) THEN 2 ELSE 0 END`, m.HomeApplicationId, m.AwayApplicationId, user).Scan(&side)
	return side, err
}
func matchReadAccess(ctx context.Context, q DBTX, c echo.Context, t contract.Tournament, m contract.Match) error {
	user := currentUser(c)
	if hasRole(c, contract.Admin) || t.Organizer.Id == user || assignedReferee(t, m, user) {
		return nil
	}
	side, err := matchCaptain(ctx, q, m, user)
	if err != nil {
		return err
	}
	if side > 0 {
		return nil
	}
	var member bool
	err = q.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM application_players WHERE application_id IN ($1,$2) AND user_id=$3)`, m.HomeApplicationId, m.AwayApplicationId, user).Scan(&member)
	if err != nil {
		return err
	}
	if !member {
		return forbidden("match participants only")
	}
	return nil
}
func assignedReferee(t contract.Tournament, m contract.Match, user uuid.UUID) bool {
	if m.RefereeId != nil {
		return *m.RefereeId == user
	}
	return t.RefereeId != nil && *t.RefereeId == user
}
func requireMatchReferee(c echo.Context, t contract.Tournament, m contract.Match) error {
	if hasRole(c, contract.Admin) {
		return nil
	}
	if !hasRole(c, contract.Referee) || !assignedReferee(t, m, currentUser(c)) {
		return forbidden("assigned referee only")
	}
	return nil
}
func notifyMatch(ctx context.Context, q DBTX, m contract.Match, kind, message string) error {
	rows, err := q.Query(ctx, `SELECT DISTINCT user_id FROM (SELECT user_id FROM application_players WHERE application_id IN ($1,$2) UNION SELECT t.captain_id AS user_id FROM applications a JOIN teams t ON t.id=a.team_id WHERE a.id IN ($1,$2)) recipients ORDER BY user_id`, m.HomeApplicationId, m.AwayApplicationId)
	if err != nil {
		return err
	}
	ids := []uuid.UUID{}
	for rows.Next() {
		var id uuid.UUID
		if err = rows.Scan(&id); err != nil {
			rows.Close()
			return err
		}
		ids = append(ids, id)
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return err
	}
	for _, id := range ids {
		if err = notify(ctx, q, id, kind, message, m.Id); err != nil {
			return err
		}
	}
	return nil
}
func matchChanged(ctx context.Context, q DBTX, actor uuid.UUID, m contract.Match, action string) error {
	if err := audit(ctx, q, actor, action, "match", m.Id, nil, m); err != nil {
		return err
	}
	return event(ctx, q, m.TournamentId, "match_updated", m)
}
func requireScheduled(m contract.Match) error {
	if m.Status != contract.MatchStatusScheduled || m.HomeApplicationId == nil || m.AwayApplicationId == nil {
		return conflict("match is not ready for a result")
	}
	if m.StartsAt == nil || m.StartsAt.After(time.Now()) {
		return conflict("match has not started")
	}
	return nil
}
func optionalUUIDEqual(a, b *uuid.UUID) bool {
	if a == nil || b == nil {
		return a == nil && b == nil
	}
	return *a == *b
}
func ignoreNoRows(err error) bool { return errors.Is(err, pgx.ErrNoRows) }
