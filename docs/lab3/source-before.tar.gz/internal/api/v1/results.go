package api

import (
	"context"
	"encoding/json"
	"time"

	"github.com/Radmila-Minnegalieva/TourneyHub/backend/internal/model"
	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

const reportJSON = `jsonb_build_object('id',r.id,'match_id',r.match_id,'author_id',r.author_id,'home_score',r.home_score,'away_score',r.away_score,'status',r.status,'confirmation_deadline',r.confirmation_deadline,'created_at',r.created_at,'games',coalesce((SELECT jsonb_agg(jsonb_build_object('number',g.number,'home_score',g.home_score,'away_score',g.away_score) ORDER BY g.number) FROM report_games g WHERE g.report_id=r.id),'[]'::jsonb),'evidence_file_ids',coalesce((SELECT jsonb_agg(f.file_id ORDER BY f.file_id) FROM report_files f WHERE f.report_id=r.id),'[]'::jsonb))`

func readReport(ctx context.Context, q DBTX, id, matchID uuid.UUID) (contract.ResultReport, error) {
	var raw []byte
	var result contract.ResultReport
	err := q.QueryRow(ctx, `SELECT `+reportJSON+` FROM result_reports r WHERE r.id=$1 AND r.match_id=$2`, id, matchID).Scan(&raw)
	if err != nil {
		return result, dbError(err)
	}
	err = json.Unmarshal(raw, &result)
	return result, err
}
func reportList(ctx context.Context, q DBTX, id uuid.UUID) ([]contract.ResultReport, error) {
	rows, err := q.Query(ctx, `SELECT `+reportJSON+` FROM result_reports r WHERE r.match_id=$1 ORDER BY r.created_at,r.id`, id)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := []contract.ResultReport{}
	for rows.Next() {
		var raw []byte
		var r contract.ResultReport
		if err = rows.Scan(&raw); err != nil {
			return nil, err
		}
		if err = json.Unmarshal(raw, &r); err != nil {
			return nil, err
		}
		result = append(result, r)
	}
	return result, rows.Err()
}
func validateResult(ctx context.Context, q DBTX, t contract.Tournament, m contract.Match, req contract.ReportResultRequest) error {
	var draw bool
	var kind string
	if err := q.QueryRow(ctx, `SELECT t.allows_draw,s.kind FROM tournaments t JOIN stages s ON s.tournament_id=t.id WHERE t.id=$1 AND s.id=$2`, t.Id, m.StageId).Scan(&draw, &kind); err != nil {
		return err
	}
	games := make([]model.Game, len(req.Games))
	for i, g := range req.Games {
		games[i] = model.Game{Number: g.Number, Home: g.HomeScore, Away: g.AwayScore}
	}
	if err := model.ValidateSeries(int(t.Rules.BestOf), req.HomeScore, req.AwayScore, games, draw, kind == "playoffs"); err != nil {
		return invalid(err.Error())
	}
	return nil
}
func validateEvidence(ctx context.Context, q DBTX, ids *[]uuid.UUID, user uuid.UUID) error {
	if ids == nil {
		return nil
	}
	seen := map[uuid.UUID]bool{}
	for _, id := range *ids {
		if seen[id] {
			return invalid("duplicate evidence file")
		}
		seen[id] = true
		var valid bool
		if err := q.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM files WHERE id=$1 AND owner_id=$2 AND purpose='match_protocol')`, id, user).Scan(&valid); err != nil {
			return err
		}
		if !valid {
			return invalid("evidence must be your own match_protocol file")
		}
	}
	return nil
}
func insertReport(ctx context.Context, q DBTX, user uuid.UUID, t contract.Tournament, m contract.Match, req contract.ReportResultRequest, source string, pending bool) (contract.ResultReport, error) {
	r := contract.ResultReport{Id: uuid.New(), MatchId: m.Id, AuthorId: user, HomeScore: req.HomeScore, AwayScore: req.AwayScore, Games: req.Games, EvidenceFileIds: []uuid.UUID{}, Status: contract.ResultReportStatusPending, CreatedAt: time.Now().UTC()}
	if err := validateResult(ctx, q, t, m, req); err != nil {
		return r, err
	}
	if err := validateEvidence(ctx, q, req.EvidenceFileIds, user); err != nil {
		return r, err
	}
	if req.EvidenceFileIds != nil {
		r.EvidenceFileIds = *req.EvidenceFileIds
	}
	if pending {
		deadline := r.CreatedAt.Add(time.Duration(t.Rules.ConfirmationTimeoutHours) * time.Hour)
		r.ConfirmationDeadline = &deadline
	}
	var reportingSide *uuid.UUID
	if source == "captain" {
		side, err := matchCaptain(ctx, q, m, user)
		if err != nil {
			return r, err
		}
		if side == 1 {
			reportingSide = m.HomeApplicationId
		} else if side == 2 {
			reportingSide = m.AwayApplicationId
		}
	}
	_, err := q.Exec(ctx, `INSERT INTO result_reports(id,match_id,author_id,source,home_score,away_score,confirmation_deadline,reporting_application_id) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`, r.Id, m.Id, user, source, r.HomeScore, r.AwayScore, r.ConfirmationDeadline, reportingSide)
	if err != nil {
		return r, err
	}
	for _, g := range r.Games {
		if _, err = q.Exec(ctx, `INSERT INTO report_games(report_id,number,home_score,away_score) VALUES($1,$2,$3,$4)`, r.Id, g.Number, g.HomeScore, g.AwayScore); err != nil {
			return r, err
		}
	}
	for _, id := range r.EvidenceFileIds {
		if _, err = q.Exec(ctx, `INSERT INTO report_files(report_id,file_id) VALUES($1,$2)`, r.Id, id); err != nil {
			return r, err
		}
	}
	return r, nil
}
func (a *API) ListResultReports(c echo.Context, id uuid.UUID) error {
	ctx := c.Request().Context()
	m, err := readMatch(ctx, a.db, id, false)
	if err != nil {
		return err
	}
	t, err := readTournament(ctx, a.db, m.TournamentId, false)
	if err != nil {
		return err
	}
	if err = matchReadAccess(ctx, a.db, c, t, m); err != nil {
		return err
	}
	result, err := reportList(ctx, a.db, id)
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}
func (a *API) ReportResult(c echo.Context, id uuid.UUID) error {
	var req contract.ReportResultRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var result contract.ResultReport
	err := a.matchTransaction(c, id, func(tx pgx.Tx, t contract.Tournament, m contract.Match) error {
		ctx := c.Request().Context()
		if err := tournamentPlaying(t); err != nil {
			return err
		}
		if err := matchVersion(m, req.Version); err != nil {
			return err
		}
		if err := requireScheduled(m); err != nil {
			return err
		}
		side, err := matchCaptain(ctx, tx, m, currentUser(c))
		if err != nil {
			return err
		}
		if side == 0 {
			return forbidden("only a participating captain can report results")
		}
		result, err = insertReport(ctx, tx, currentUser(c), t, m, req, "captain", true)
		if err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE matches SET status='awaiting_confirmation',version=version+1,updated_at=now() WHERE id=$1`, id); err != nil {
			return err
		}
		m.Status = contract.MatchStatusAwaitingConfirmation
		m.Version++
		if err = matchChanged(ctx, tx, currentUser(c), m, "result.reported"); err != nil {
			return err
		}
		return notifyMatch(ctx, tx, m, "result_confirmation", "Результат матча ожидает подтверждения соперником")
	})
	if err != nil {
		return err
	}
	return c.JSON(201, result)
}
func opposingCaptain(ctx context.Context, q DBTX, c echo.Context, m contract.Match, r contract.ResultReport) error {
	side, err := matchCaptain(ctx, q, m, currentUser(c))
	if err != nil {
		return err
	}
	if side == 0 {
		return forbidden("only the opposing captain may act")
	}
	var reportingSide *uuid.UUID
	err = q.QueryRow(ctx, `SELECT reporting_application_id FROM result_reports WHERE id=$1`, r.Id).Scan(&reportingSide)
	if err != nil {
		return err
	}
	ownSide := m.HomeApplicationId
	if side == 2 {
		ownSide = m.AwayApplicationId
	}
	if optionalUUIDEqual(reportingSide, ownSide) || currentUser(c) == r.AuthorId {
		return forbidden("the reporting side cannot confirm or dispute its own report")
	}

	return nil
}
func (a *API) ConfirmResult(c echo.Context, id, reportID uuid.UUID) error {
	var req contract.VersionRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var result contract.Match
	err := a.matchTransaction(c, id, func(tx pgx.Tx, t contract.Tournament, m contract.Match) error {
		ctx := c.Request().Context()
		r, err := readReport(ctx, tx, reportID, id)
		if err != nil {
			return err
		}
		if err = opposingCaptain(ctx, tx, c, m, r); err != nil {
			return err
		}
		if m.Status == contract.MatchStatusCompleted && r.Status == contract.ResultReportStatusConfirmed {
			result = m
			return nil
		}
		if err = matchVersion(m, req.Version); err != nil {
			return err
		}
		if err = tournamentPlaying(t); err != nil {
			return err
		}
		if m.Status != contract.MatchStatusAwaitingConfirmation || r.Status != contract.ResultReportStatusPending {
			return conflict("report is no longer pending")
		}
		result, err = finalizeResult(ctx, tx, currentUser(c), t, m, r)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}
func (a *API) SetRefereeResult(c echo.Context, id uuid.UUID) error {
	var req contract.ReportResultRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var result contract.Match
	err := a.matchTransaction(c, id, func(tx pgx.Tx, t contract.Tournament, m contract.Match) error {
		if err := requireMatchReferee(c, t, m); err != nil {
			return err
		}
		if err := matchVersion(m, req.Version); err != nil {
			return err
		}
		if err := tournamentPlaying(t); err != nil {
			return err
		}
		if m.Status == contract.MatchStatusCompleted || m.Status == contract.MatchStatusBye || m.Status == contract.MatchStatusDisputed {
			return conflict("use dispute resolution for a disputed or completed match")
		}
		scheduled := m
		scheduled.Status = contract.MatchStatusScheduled
		if err := requireScheduled(scheduled); err != nil {
			return err
		}
		ctx := c.Request().Context()
		if _, err := tx.Exec(ctx, `UPDATE result_reports SET status='superseded' WHERE match_id=$1 AND status='pending'`, id); err != nil {
			return err
		}
		r, err := insertReport(ctx, tx, currentUser(c), t, m, req, "referee", false)
		if err != nil {
			return err
		}
		result, err = finalizeResult(ctx, tx, currentUser(c), t, m, r)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}
func finalizeResult(ctx context.Context, tx pgx.Tx, actor uuid.UUID, t contract.Tournament, m contract.Match, r contract.ResultReport) (contract.Match, error) {
	if _, err := tx.Exec(ctx, `SELECT pg_advisory_xact_lock(hashtextextended($1::text,913))`, t.DisciplineId.String()); err != nil {
		return m, err
	}
	correction := m.HomeScore != nil
	winner := scoreWinner(m, r.HomeScore, r.AwayScore)
	if err := updateProgression(ctx, tx, m, winner); err != nil {
		return m, err
	}
	if _, err := tx.Exec(ctx, `UPDATE result_reports SET status='superseded' WHERE match_id=$1 AND id<>$2 AND status IN ('pending','confirmed','disputed')`, m.Id, r.Id); err != nil {
		return m, err
	}
	var by *uuid.UUID
	if actor != uuid.Nil {
		by = &actor
	}
	if _, err := tx.Exec(ctx, `UPDATE result_reports SET status='confirmed',confirmed_by=$2,confirmed_at=coalesce(confirmed_at,clock_timestamp()) WHERE id=$1`, r.Id, by); err != nil {
		return m, err
	}
	_, err := tx.Exec(ctx, `UPDATE matches SET status='completed',home_score=$2,away_score=$3,winner_application_id=$4,final_report_id=$5,version=version+1,updated_at=now() WHERE id=$1`, m.Id, r.HomeScore, r.AwayScore, winner, r.Id)
	if err != nil {
		return m, err
	}
	m.Status = contract.MatchStatusCompleted
	m.HomeScore = &r.HomeScore
	m.AwayScore = &r.AwayScore
	m.WinnerApplicationId = winner
	m.Version++
	if err = recordMatchRating(ctx, tx, t.Id, t.DisciplineId, ratingMatch{id: m.Id, homeScore: r.HomeScore, awayScore: r.AwayScore}, correction); err != nil {
		return m, err
	}
	if err = rebuildStandings(ctx, tx, t, m.StageId); err != nil {
		return m, err
	}
	if err = finishStage(ctx, tx, t, m.StageId); err != nil {
		return m, err
	}
	if err = matchChanged(ctx, tx, actor, m, "result.confirmed"); err != nil {
		return m, err
	}
	return m, notifyMatch(ctx, tx, m, "result_confirmed", "Зафиксирован итоговый результат матча")
}
func scoreWinner(m contract.Match, home, away int) *uuid.UUID {
	if home > away {
		return m.HomeApplicationId
	}
	if away > home {
		return m.AwayApplicationId
	}
	return nil
}
