package api

import (
	"context"
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
	"time"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

const applicationJSON = `jsonb_build_object(
 'id',a.id,'tournament_id',a.tournament_id,'status',a.status,'version',a.version,
 'seed',a.seed,'final_place',a.final_place,'rejection_reason',a.rejection_reason,'created_at',a.created_at,
 'team',jsonb_build_object('id',tm.id,'name',tm.name,'description',tm.description,
 'captain_id',tm.captain_id,'personal',tm.personal,'version',tm.version,
 'logo_url',CASE WHEN tm.logo_file_id IS NOT NULL THEN '/api/v1/files/'||tm.logo_file_id END),
 'players',COALESCE((SELECT jsonb_agg(jsonb_build_object('id',u.id,'nickname',u.nickname,
 'name',u.name,'avatar_url',CASE WHEN u.avatar_file_id IS NOT NULL THEN '/api/v1/files/'||u.avatar_file_id END)
 ORDER BY u.nickname,u.id) FROM application_players ap JOIN users u ON u.id=ap.user_id
 WHERE ap.application_id=a.id),'[]'::jsonb))`

func sqlPlaceholder(number int) string { return "$" + strconv.Itoa(number) }

func readApplication(ctx context.Context, q DBTX, id uuid.UUID) (contract.Application, error) {
	var result contract.Application
	var raw []byte
	err := q.QueryRow(ctx, `SELECT `+applicationJSON+` FROM applications a JOIN teams tm ON tm.id=a.team_id WHERE a.id=$1`, id).Scan(&raw)
	if err != nil {
		return result, dbError(err)
	}
	err = json.Unmarshal(raw, &result)
	return result, err
}

func (a *API) applicationPage(c echo.Context, limitPointer, offsetPointer *int, where string, args ...any) error {
	limit, offset := pagination(limitPointer, offsetPointer)
	page := contract.ApplicationPage{Items: []contract.Application{}, Limit: limit, Offset: offset}
	ctx := c.Request().Context()
	from := ` FROM applications a JOIN teams tm ON tm.id=a.team_id WHERE ` + where
	if err := a.db.QueryRow(ctx, `SELECT count(*)`+from, args...).Scan(&page.Total); err != nil {
		return dbError(err)
	}
	// Условия и номера параметров определены только вызывающим кодом, значения не интерполируются в SQL.
	rows, err := a.db.Query(ctx, `SELECT `+applicationJSON+from+` ORDER BY a.created_at DESC,a.id ASC LIMIT `+sqlPlaceholder(len(args)+1)+` OFFSET `+sqlPlaceholder(len(args)+2), append(args, limit, offset)...)
	if err != nil {
		return dbError(err)
	}
	defer rows.Close()
	for rows.Next() {
		var raw []byte
		var item contract.Application
		if err := rows.Scan(&raw); err != nil {
			return err
		}
		if err := json.Unmarshal(raw, &item); err != nil {
			return err
		}
		page.Items = append(page.Items, item)
	}
	if err := rows.Err(); err != nil {
		return err
	}
	return c.JSON(http.StatusOK, page)
}

func (a *API) ListApplications(c echo.Context, id uuid.UUID, p contract.ListApplicationsParams) error {
	t, err := readTournament(c.Request().Context(), a.db, id, false)
	if err != nil {
		return err
	}
	if err := requireTournamentOwner(c, t); err != nil {
		return err
	}
	return a.applicationPage(c, p.Limit, p.Offset, `a.tournament_id=$1 AND ($2::text IS NULL OR a.status=$2)`, id, p.Status)
}

func (a *API) ListParticipants(c echo.Context, id uuid.UUID, p contract.ListParticipantsParams) error {
	if err := tournamentPublic(c.Request().Context(), a.db, id); err != nil {
		return err
	}
	return a.applicationPage(c, p.Limit, p.Offset, `a.tournament_id=$1 AND a.status='accepted'`, id)
}

func (a *API) ListMyApplications(c echo.Context, p contract.ListMyApplicationsParams) error {
	return a.applicationPage(c, p.Limit, p.Offset, `(EXISTS(SELECT 1 FROM team_members m WHERE m.team_id=a.team_id AND m.user_id=$1) OR EXISTS(SELECT 1 FROM application_players ap WHERE ap.application_id=a.id AND ap.user_id=$1))`, currentUser(c))
}

func registrationOpen(t contract.Tournament, now time.Time) bool {
	return t.Status == contract.TournamentStatusRegistration && !t.Hidden && t.RegistrationOpensAt != nil && t.RegistrationClosesAt != nil && !now.Before(*t.RegistrationOpensAt) && now.Before(*t.RegistrationClosesAt)
}

func (a *API) SubmitApplication(c echo.Context, id uuid.UUID) error {
	var r contract.ApplicationRequest
	if err := bindJSON(c, &r); err != nil {
		return err
	}
	var result contract.Application
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		t, err := readTournament(ctx, tx, id, true)
		if err != nil {
			return err
		}
		if !registrationOpen(t, time.Now()) {
			return conflict("registration is not open")
		}
		if t.AcceptedCount >= t.MaxParticipants {
			return conflict("the tournament has no available places")
		}
		team, err := applicationTeam(ctx, tx, currentUser(c), id, r)
		if err != nil {
			return err
		}
		applicationID := uuid.New()
		_, err = tx.Exec(ctx, `INSERT INTO applications(id,tournament_id,team_id,submitted_by) VALUES($1,$2,$3,$4)`, applicationID, id, team, currentUser(c))
		if err != nil {
			return dbError(err)
		}
		if err := reserveApplicationPlayers(ctx, tx, applicationID, id, r.PlayerIds); err != nil {
			return err
		}
		result, err = readApplication(ctx, tx, applicationID)
		if err != nil {
			return err
		}
		if err := applicationChanged(ctx, tx, currentUser(c), id, applicationID, "application_submitted", nil, result); err != nil {
			return err
		}
		return notify(ctx, tx, t.Organizer.Id, "application_submitted", "A new tournament application needs review", applicationID)
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusCreated, result)
}

func applicationTeam(ctx context.Context, tx pgx.Tx, userID, tournamentID uuid.UUID, r contract.ApplicationRequest) (uuid.UUID, error) {
	var minRoster, maxRoster int
	if err := tx.QueryRow(ctx, `SELECT min_roster_size,max_roster_size FROM tournaments WHERE id=$1`, tournamentID).Scan(&minRoster, &maxRoster); err != nil {
		return uuid.Nil, err
	}
	if len(r.PlayerIds) < minRoster || len(r.PlayerIds) > maxRoster {
		return uuid.Nil, invalid("roster size does not match the discipline")
	}
	team := r.TeamId
	if team == nil {
		if minRoster != 1 || maxRoster != 1 || len(r.PlayerIds) != 1 || r.PlayerIds[0] != userID {
			return uuid.Nil, invalid("an individual application must contain only the current player")
		}
		id, err := ensurePersonalTeam(ctx, tx, userID)
		if err != nil {
			return uuid.Nil, err
		}
		team = &id
	}
	var captain uuid.UUID
	if err := tx.QueryRow(ctx, `SELECT captain_id FROM teams WHERE id=$1 AND deleted_at IS NULL FOR SHARE`, *team).Scan(&captain); err != nil {
		return uuid.Nil, dbError(err)
	}
	if captain != userID {
		return uuid.Nil, forbidden("only the team captain can submit an application")
	}
	if err := validateApplicationPlayers(ctx, tx, *team, r.PlayerIds); err != nil {
		return uuid.Nil, err
	}
	return *team, nil
}

func validateApplicationPlayers(ctx context.Context, q DBTX, teamID uuid.UUID, players []uuid.UUID) error {
	seen := make(map[uuid.UUID]bool)
	for _, id := range players {
		if seen[id] {
			return invalid("players must be unique")
		}
		seen[id] = true
	}
	var count int
	err := q.QueryRow(ctx, `SELECT count(*) FROM team_members m JOIN users u ON u.id=m.user_id WHERE m.team_id=$1 AND m.user_id=ANY($2::uuid[]) AND u.blocked_at IS NULL AND u.email_verified_at IS NOT NULL`, teamID, players).Scan(&count)
	if err != nil {
		return err
	}
	if count != len(players) {
		return invalid("every player must be an active verified member of the team")
	}
	return nil
}

func reserveApplicationPlayers(ctx context.Context, q DBTX, applicationID, tournamentID uuid.UUID, players []uuid.UUID) error {
	if _, err := q.Exec(ctx, `INSERT INTO application_players(application_id,tournament_id,user_id) SELECT $1,$2,unnest($3::uuid[])`, applicationID, tournamentID, players); err != nil {
		return dbError(err)
	}
	_, err := q.Exec(ctx, `INSERT INTO tournament_player_claims(tournament_id,user_id,application_id) SELECT $1,unnest($2::uuid[]),$3`, tournamentID, players, applicationID)
	return dbError(err)
}

func applicationChanged(ctx context.Context, q DBTX, actor, tournamentID, applicationID uuid.UUID, action string, before, after any) error {
	if _, err := q.Exec(ctx, `UPDATE tournaments SET version=version+1,updated_at=now() WHERE id=$1`, tournamentID); err != nil {
		return err
	}
	if err := audit(ctx, q, actor, action, "application", applicationID, before, after); err != nil {
		return err
	}
	return event(ctx, q, tournamentID, "tournament_updated", map[string]any{"application_id": applicationID, "action": action})
}

func (a *API) ReviewApplication(c echo.Context, tournamentID, applicationID uuid.UUID) error {
	var r contract.ReviewApplicationRequest
	if err := bindJSON(c, &r); err != nil {
		return err
	}
	if !r.Decision.Valid() || (r.Decision == contract.ReviewApplicationRequestDecisionReject && (r.Reason == nil || strings.TrimSpace(*r.Reason) == "")) {
		return invalid("a valid decision and rejection reason are required")
	}
	return a.mutateApplication(c, tournamentID, applicationID, r.Version, "application_reviewed", func(ctx context.Context, tx pgx.Tx, t contract.Tournament, before contract.Application) error {
		if err := requireTournamentOwner(c, t); err != nil {
			return err
		}
		if t.Status != contract.TournamentStatusRegistration || before.Status != contract.ApplicationStatusPending {
			return conflict("only a pending application can be reviewed during registration")
		}
		status := "rejected"
		if r.Decision == contract.ReviewApplicationRequestDecisionAccept {
			if t.AcceptedCount >= t.MaxParticipants {
				return conflict("the tournament has no available places")
			}
			status = "accepted"
		}
		if status == "rejected" {
			if _, err := tx.Exec(ctx, `DELETE FROM tournament_player_claims WHERE application_id=$1`, applicationID); err != nil {
				return err
			}
		}
		_, err := tx.Exec(ctx, `UPDATE applications SET status=$2,rejection_reason=CASE WHEN $2='rejected' THEN $3 ELSE NULL END WHERE id=$1`, applicationID, status, r.Reason)
		if err != nil {
			return err
		}
		return notify(ctx, tx, before.Team.CaptainId, "application_reviewed", "Your tournament application was "+status, applicationID)
	})
}

func (a *API) WithdrawApplication(c echo.Context, tournamentID, applicationID uuid.UUID) error {
	var r contract.VersionRequest
	if err := bindJSON(c, &r); err != nil {
		return err
	}
	return a.mutateApplication(c, tournamentID, applicationID, r.Version, "application_withdrawn", func(ctx context.Context, tx pgx.Tx, t contract.Tournament, before contract.Application) error {
		if before.Team.CaptainId != currentUser(c) {
			return forbidden("only the team captain can withdraw an application")
		}
		if !registrationOpen(t, time.Now()) || (before.Status != contract.ApplicationStatusPending && before.Status != contract.ApplicationStatusAccepted) {
			return conflict("the application cannot be withdrawn after registration closes")
		}
		if _, err := tx.Exec(ctx, `DELETE FROM tournament_player_claims WHERE application_id=$1`, applicationID); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE applications SET status='withdrawn' WHERE id=$1`, applicationID); err != nil {
			return err
		}
		return notify(ctx, tx, t.Organizer.Id, "application_withdrawn", "A tournament application was withdrawn", applicationID)
	})
}

func (a *API) mutateApplication(c echo.Context, tournamentID, applicationID uuid.UUID, version int, action string, mutate func(context.Context, pgx.Tx, contract.Tournament, contract.Application) error) error {
	var result contract.Application
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		t, err := readTournament(ctx, tx, tournamentID, true)
		if err != nil {
			return err
		}
		var found uuid.UUID
		if err := tx.QueryRow(ctx, `SELECT id FROM applications WHERE id=$1 AND tournament_id=$2 FOR UPDATE`, applicationID, tournamentID).Scan(&found); err != nil {
			return dbError(err)
		}
		var team uuid.UUID
		if err := tx.QueryRow(ctx, `SELECT tm.id FROM teams tm JOIN applications a ON a.team_id=tm.id WHERE a.id=$1 FOR SHARE OF tm`, applicationID).Scan(&team); err != nil {
			return dbError(err)
		}
		before, err := readApplication(ctx, tx, found)
		if err != nil {
			return err
		}
		if before.Version != version {
			return conflict("application version is stale")
		}
		if err := mutate(ctx, tx, t, before); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `UPDATE applications SET version=version+1,updated_at=now() WHERE id=$1`, found); err != nil {
			return err
		}
		result, err = readApplication(ctx, tx, found)
		if err != nil {
			return err
		}
		return applicationChanged(ctx, tx, currentUser(c), tournamentID, applicationID, action, before, result)
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, result)
}
