package api

import (
	"context"
	"crypto/subtle"
	"errors"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

const teamColumns = `t.id,t.name,t.description,t.captain_id,t.personal,t.version,
 CASE WHEN t.logo_file_id IS NULL THEN NULL ELSE '/api/v1/files/'||t.logo_file_id END`

func scanTeam(row identityScanner) (contract.Team, error) {
	var t contract.Team
	err := row.Scan(&t.Id, &t.Name, &t.Description, &t.CaptainId, &t.Personal, &t.Version, &t.LogoUrl)
	return t, err
}

func loadTeam(ctx context.Context, q DBTX, id uuid.UUID) (contract.Team, error) {
	t, err := scanTeam(q.QueryRow(ctx, `SELECT `+teamColumns+` FROM teams t WHERE t.id=$1 AND t.deleted_at IS NULL`, id))
	return t, dbError(err)
}

func lockTeam(ctx context.Context, q DBTX, id uuid.UUID) (contract.Team, error) {
	t, err := scanTeam(q.QueryRow(ctx, `SELECT `+teamColumns+` FROM teams t WHERE t.id=$1 AND t.deleted_at IS NULL FOR UPDATE`, id))
	return t, dbError(err)
}

func captainTeam(ctx context.Context, q DBTX, teamID, userID uuid.UUID) (contract.Team, error) {
	t, err := lockTeam(ctx, q, teamID)
	if err != nil {
		return t, err
	}
	if t.CaptainId != userID {
		return t, forbidden("only the team captain can perform this action")
	}
	return t, nil
}

func teamVersion(t contract.Team, expected int) error {
	if t.Version != expected {
		return conflict("team version changed")
	}
	return nil
}

func validTeamLogo(ctx context.Context, q DBTX, fileID *uuid.UUID, ownerID uuid.UUID) error {
	if fileID == nil {
		return nil
	}
	var allowed bool
	if err := q.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM files WHERE id=$1 AND owner_id=$2 AND purpose='team_logo')`, *fileID, ownerID).Scan(&allowed); err != nil {
		return err
	}
	if !allowed {
		return invalid("team logo must be an owned team_logo file")
	}
	return nil
}

// ensurePersonalTeam создаёт команду из одного игрока для индивидуальной заявки.
// Блокировка пользователя сериализует параллельные первые заявки без потери транзакции на UNIQUE.
func ensurePersonalTeam(ctx context.Context, q DBTX, userID uuid.UUID) (uuid.UUID, error) {
	var nickname string
	if err := q.QueryRow(ctx, `SELECT nickname FROM users WHERE id=$1 FOR UPDATE`, userID).Scan(&nickname); err != nil {
		return uuid.Nil, err
	}
	var id uuid.UUID
	err := q.QueryRow(ctx, `SELECT id FROM teams WHERE captain_id=$1 AND personal AND deleted_at IS NULL`, userID).Scan(&id)
	if err == nil {
		return id, nil
	}
	if !errors.Is(err, pgx.ErrNoRows) {
		return uuid.Nil, err
	}
	if err = q.QueryRow(ctx, `INSERT INTO teams(name,captain_id,personal) VALUES($1,$2,true) RETURNING id`, nickname, userID).Scan(&id); err != nil {
		return uuid.Nil, err
	}
	_, err = q.Exec(ctx, `INSERT INTO team_members(team_id,user_id) VALUES($1,$2)`, id, userID)
	return id, err
}

func (a *API) listTeams(c echo.Context, limitParam, offsetParam *int, search string, mine bool) error {
	ctx := c.Request().Context()
	limit, offset := pagination(limitParam, offsetParam)
	var owner *uuid.UUID
	if mine {
		id := currentUser(c)
		owner = &id
	}
	where := `t.deleted_at IS NULL AND ($1='' OR strpos(lower(t.name),lower($1))>0) AND ($2::uuid IS NULL OR EXISTS(SELECT 1 FROM team_members tm WHERE tm.team_id=t.id AND tm.user_id=$2))`
	var total int
	if err := a.db.QueryRow(ctx, `SELECT count(*) FROM teams t WHERE `+where, search, owner).Scan(&total); err != nil {
		return dbError(err)
	}
	rows, err := a.db.Query(ctx, `SELECT `+teamColumns+` FROM teams t WHERE `+where+` ORDER BY t.created_at DESC,t.id LIMIT $3 OFFSET $4`, search, owner, limit, offset)
	if err != nil {
		return dbError(err)
	}
	defer rows.Close()
	items := make([]contract.Team, 0)
	for rows.Next() {
		t, err := scanTeam(rows)
		if err != nil {
			return dbError(err)
		}
		items = append(items, t)
	}
	if err := rows.Err(); err != nil {
		return dbError(err)
	}
	return c.JSON(http.StatusOK, contract.TeamPage{Items: items, Limit: limit, Offset: offset, Total: total})
}

func (a *API) ListTeams(c echo.Context, params contract.ListTeamsParams) error {
	search := ""
	if params.Search != nil {
		search = *params.Search
	}
	return a.listTeams(c, params.Limit, params.Offset, search, false)
}

func (a *API) ListMyTeams(c echo.Context, params contract.ListMyTeamsParams) error {
	return a.listTeams(c, params.Limit, params.Offset, "", true)
}

func (a *API) GetTeam(c echo.Context, teamID uuid.UUID) error {
	t, err := loadTeam(c.Request().Context(), a.db, teamID)
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, t)
}

func (a *API) CreateTeam(c echo.Context) error {
	if err := requireRole(c, contract.Participant); err != nil {
		return err
	}
	var req contract.CreateTeamRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	if strings.TrimSpace(req.Name) == "" {
		return invalid("team name cannot be blank")
	}
	var t contract.Team
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx, owner := c.Request().Context(), currentUser(c)
		if err := validTeamLogo(ctx, tx, req.LogoFileId, owner); err != nil {
			return err
		}
		var id uuid.UUID
		if err := tx.QueryRow(ctx, `INSERT INTO teams(name,description,logo_file_id,captain_id) VALUES($1,COALESCE($2,''),$3,$4) RETURNING id`, req.Name, req.Description, req.LogoFileId, owner).Scan(&id); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO team_members(team_id,user_id) VALUES($1,$2)`, id, owner); err != nil {
			return err
		}
		var err error
		t, err = loadTeam(ctx, tx, id)
		if err != nil {
			return err
		}
		return audit(ctx, tx, owner, "team_created", "team", id, nil, t)
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusCreated, t)
}

func (a *API) UpdateTeam(c echo.Context, teamID uuid.UUID) error {
	var req contract.UpdateTeamRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	if req.Name != nil && strings.TrimSpace(*req.Name) == "" {
		return invalid("team name cannot be blank")
	}
	var t contract.Team
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx, actor := c.Request().Context(), currentUser(c)
		before, err := captainTeam(ctx, tx, teamID, actor)
		if err != nil {
			return err
		}
		if err := teamVersion(before, req.Version); err != nil {
			return err
		}
		if err := validTeamLogo(ctx, tx, req.LogoFileId, actor); err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `UPDATE teams SET name=COALESCE($2,name),description=COALESCE($3,description),logo_file_id=COALESCE($4,logo_file_id),version=version+1,updated_at=now() WHERE id=$1`, teamID, req.Name, req.Description, req.LogoFileId)
		if err != nil {
			return err
		}
		t, err = loadTeam(ctx, tx, teamID)
		if err != nil {
			return err
		}
		return audit(ctx, tx, actor, "team_updated", "team", teamID, before, t)
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, t)
}

func (a *API) DeleteTeam(c echo.Context, teamID uuid.UUID) error {
	var req contract.VersionRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx, actor := c.Request().Context(), currentUser(c)
		t, err := captainTeam(ctx, tx, teamID, actor)
		if err != nil {
			return err
		}
		if err := teamVersion(t, req.Version); err != nil {
			return err
		}
		var active bool
		if err := tx.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM applications a JOIN tournaments t ON t.id=a.tournament_id WHERE a.team_id=$1 AND a.status='accepted' AND t.status IN ('registration','in_progress') AND t.deleted_at IS NULL)`, teamID).Scan(&active); err != nil {
			return err
		}
		if active {
			return conflict("team has accepted applications in active tournaments")
		}
		if _, err = tx.Exec(ctx, `DELETE FROM tournament_player_claims WHERE application_id IN (SELECT id FROM applications WHERE team_id=$1 AND status='pending')`, teamID); err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE applications SET status='withdrawn',version=version+1,updated_at=now() WHERE team_id=$1 AND status='pending'`, teamID); err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE invitations SET status='revoked' WHERE team_id=$1 AND status='pending'`, teamID); err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE teams SET deleted_at=now(),version=version+1,updated_at=now() WHERE id=$1`, teamID); err != nil {
			return err
		}
		return audit(ctx, tx, actor, "team_deleted", "team", teamID, t, nil)
	})
	if err != nil {
		return err
	}
	return c.NoContent(http.StatusNoContent)
}

func (a *API) ListTeamMembers(c echo.Context, teamID uuid.UUID) error {
	ctx := c.Request().Context()
	if _, err := loadTeam(ctx, a.db, teamID); err != nil {
		return err
	}
	rows, err := a.db.Query(ctx, `SELECT u.id,u.nickname,u.name,CASE WHEN u.avatar_file_id IS NULL THEN NULL ELSE '/api/v1/files/'||u.avatar_file_id END,tm.joined_at,u.id=t.captain_id FROM team_members tm JOIN users u ON u.id=tm.user_id JOIN teams t ON t.id=tm.team_id WHERE tm.team_id=$1 ORDER BY u.id=t.captain_id DESC,tm.joined_at,u.id`, teamID)
	if err != nil {
		return dbError(err)
	}
	defer rows.Close()
	items := make([]contract.TeamMember, 0)
	for rows.Next() {
		var m contract.TeamMember
		if err := rows.Scan(&m.User.Id, &m.User.Nickname, &m.User.Name, &m.User.AvatarUrl, &m.JoinedAt, &m.Captain); err != nil {
			return dbError(err)
		}
		items = append(items, m)
	}
	if err := rows.Err(); err != nil {
		return dbError(err)
	}
	return c.JSON(http.StatusOK, items)
}

func (a *API) RemoveTeamMember(c echo.Context, teamID, userID uuid.UUID) error {
	var req contract.VersionRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx, actor := c.Request().Context(), currentUser(c)
		t, err := lockTeam(ctx, tx, teamID)
		if err != nil {
			return err
		}
		if actor != t.CaptainId && actor != userID {
			return forbidden("only captain or the member can remove membership")
		}
		if t.CaptainId == userID {
			return conflict("captain must transfer captaincy before leaving")
		}
		if err := teamVersion(t, req.Version); err != nil {
			return err
		}
		tag, err := tx.Exec(ctx, `DELETE FROM team_members WHERE team_id=$1 AND user_id=$2`, teamID, userID)
		if err != nil {
			return err
		}
		if tag.RowsAffected() == 0 {
			return notFound("team member not found")
		}
		if _, err = tx.Exec(ctx, `UPDATE teams SET version=version+1,updated_at=now() WHERE id=$1`, teamID); err != nil {
			return err
		}
		return audit(ctx, tx, actor, "team_member_removed", "team", teamID, map[string]any{"user_id": userID}, nil)
	})
	if err != nil {
		return err
	}
	return c.NoContent(http.StatusNoContent)
}

func (a *API) TransferCaptain(c echo.Context, teamID uuid.UUID) error {
	var req contract.TransferCaptainRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var t contract.Team
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx, actor := c.Request().Context(), currentUser(c)
		before, err := captainTeam(ctx, tx, teamID, actor)
		if err != nil {
			return err
		}
		if before.Personal {
			return conflict("personal team cannot change captain")
		}
		if err := teamVersion(before, req.Version); err != nil {
			return err
		}
		var allowed bool
		if err := tx.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM team_members tm JOIN users u ON u.id=tm.user_id WHERE tm.team_id=$1 AND tm.user_id=$2 AND u.blocked_at IS NULL)`, teamID, req.UserId).Scan(&allowed); err != nil {
			return err
		}
		if !allowed {
			return invalid("new captain must be an unblocked team member")
		}
		if _, err = tx.Exec(ctx, `UPDATE teams SET captain_id=$2,version=version+1,updated_at=now() WHERE id=$1`, teamID, req.UserId); err != nil {
			return err
		}
		t, err = loadTeam(ctx, tx, teamID)
		if err != nil {
			return err
		}
		return audit(ctx, tx, actor, "team_captain_transferred", "team", teamID, before, t)
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, t)
}

func invitationURL(id uuid.UUID, token string) string {
	base := strings.TrimRight(os.Getenv("PUBLIC_WEB_URL"), "/")
	if base == "" {
		base = "http://localhost:5173"
	}
	return base + "/invitations/" + id.String() + "?token=" + url.QueryEscape(token)
}

func (a *API) CreateInvitation(c echo.Context, teamID uuid.UUID) error {
	var req contract.CreateInvitationRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	token, err := secretToken()
	if err != nil {
		return err
	}
	invitation := contract.Invitation{TeamId: teamID, Status: contract.InvitationStatusPending}
	err = a.withTx(c, func(tx pgx.Tx) error {
		ctx, actor := c.Request().Context(), currentUser(c)
		t, err := captainTeam(ctx, tx, teamID, actor)
		if err != nil {
			return err
		}
		if t.Personal {
			return conflict("personal team can contain only its owner")
		}
		if req.Nickname != nil {
			var invitee uuid.UUID
			if err := tx.QueryRow(ctx, `SELECT id FROM users WHERE lower(nickname)=lower($1) AND blocked_at IS NULL AND email_verified_at IS NOT NULL`, *req.Nickname).Scan(&invitee); err != nil {
				return err
			}
			var member bool
			if err := tx.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM team_members WHERE team_id=$1 AND user_id=$2)`, teamID, invitee).Scan(&member); err != nil {
				return err
			}
			if member {
				return conflict("player is already a team member")
			}
			invitation.InviteeId = &invitee
		}
		if err := tx.QueryRow(ctx, `INSERT INTO invitations(team_id,invitee_id,created_by,token_hash,expires_at) VALUES($1,$2,$3,$4,now()+interval '7 days') RETURNING id,expires_at`, teamID, invitation.InviteeId, actor, tokenHash(token)).Scan(&invitation.Id, &invitation.ExpiresAt); err != nil {
			return err
		}
		if invitation.InviteeId != nil {
			return notify(ctx, tx, *invitation.InviteeId, "team_invitation", "Приглашение в команду "+t.Name, invitation.Id)
		}
		return nil
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusCreated, contract.InvitationLink{Invitation: invitation, Token: token, Url: invitationURL(invitation.Id, token)})
}

func scanInvitation(row identityScanner) (contract.Invitation, error) {
	var invitation contract.Invitation
	err := row.Scan(&invitation.Id, &invitation.TeamId, &invitation.InviteeId, &invitation.Status, &invitation.ExpiresAt)
	return invitation, err
}

func (a *API) ListMyInvitations(c echo.Context, params contract.ListMyInvitationsParams) error {
	ctx, actor := c.Request().Context(), currentUser(c)
	limit, offset := pagination(params.Limit, params.Offset)
	where := `(invitee_id=$1 OR consumed_by=$1)`
	var total int
	if err := a.db.QueryRow(ctx, `SELECT count(*) FROM invitations WHERE `+where, actor).Scan(&total); err != nil {
		return dbError(err)
	}
	rows, err := a.db.Query(ctx, `SELECT id,team_id,invitee_id,CASE WHEN status='pending' AND expires_at<=now() THEN 'expired' ELSE status END,expires_at FROM invitations WHERE `+where+` ORDER BY created_at DESC,id LIMIT $2 OFFSET $3`, actor, limit, offset)
	if err != nil {
		return dbError(err)
	}
	defer rows.Close()
	items := make([]contract.Invitation, 0)
	for rows.Next() {
		i, err := scanInvitation(rows)
		if err != nil {
			return dbError(err)
		}
		items = append(items, i)
	}
	if err := rows.Err(); err != nil {
		return dbError(err)
	}
	return c.JSON(http.StatusOK, contract.InvitationPage{Items: items, Limit: limit, Offset: offset, Total: total})
}

func (a *API) DecideInvitation(c echo.Context, invitationID uuid.UUID) error {
	var req contract.InvitationDecisionRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var invitation contract.Invitation
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx, actor := c.Request().Context(), currentUser(c)
		var teamID uuid.UUID
		if err := tx.QueryRow(ctx, `SELECT team_id FROM invitations WHERE id=$1`, invitationID).Scan(&teamID); err != nil {
			return err
		}
		t, err := lockTeam(ctx, tx, teamID)
		if err != nil {
			return err
		}
		var hash string
		err = tx.QueryRow(ctx, `SELECT id,team_id,invitee_id,status,expires_at,token_hash FROM invitations WHERE id=$1 FOR UPDATE`, invitationID).Scan(&invitation.Id, &invitation.TeamId, &invitation.InviteeId, &invitation.Status, &invitation.ExpiresAt, &hash)
		if err != nil {
			return err
		}
		if invitation.InviteeId != nil {
			if *invitation.InviteeId != actor {
				return forbidden("invitation belongs to another player")
			}
		} else {
			if req.Token == nil || subtle.ConstantTimeCompare([]byte(hash), []byte(tokenHash(*req.Token))) != 1 {
				return forbidden("invalid invitation token")
			}
		}
		if invitation.Status != contract.InvitationStatusPending || !invitation.ExpiresAt.After(time.Now()) {
			return conflict("invitation is already consumed or expired")
		}
		if t.Personal {
			return conflict("personal team cannot accept members")
		}
		invitation.Status = contract.InvitationStatusDeclined
		if req.Decision == contract.InvitationDecisionRequestDecisionAccept {
			tag, err := tx.Exec(ctx, `INSERT INTO team_members(team_id,user_id) VALUES($1,$2) ON CONFLICT DO NOTHING`, teamID, actor)
			if err != nil {
				return err
			}
			if tag.RowsAffected() == 0 {
				return conflict("player is already a team member")
			}
			if _, err = tx.Exec(ctx, `UPDATE teams SET version=version+1,updated_at=now() WHERE id=$1`, teamID); err != nil {
				return err
			}
			invitation.Status = contract.InvitationStatusAccepted
		}
		if _, err = tx.Exec(ctx, `UPDATE invitations SET status=$2,consumed_by=$3 WHERE id=$1`, invitationID, string(invitation.Status), actor); err != nil {
			return err
		}
		return notify(ctx, tx, t.CaptainId, "invitation_decided", "Ответ на приглашение в команду "+t.Name, invitationID)
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, invitation)
}

func (a *API) RevokeInvitation(c echo.Context, teamID, invitationID uuid.UUID) error {
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		if _, err := captainTeam(ctx, tx, teamID, currentUser(c)); err != nil {
			return err
		}
		var status string
		if err := tx.QueryRow(ctx, `SELECT status FROM invitations WHERE id=$1 AND team_id=$2 FOR UPDATE`, invitationID, teamID).Scan(&status); err != nil {
			return err
		}
		if status != "pending" && status != "revoked" {
			return conflict("invitation has already been consumed")
		}
		_, err := tx.Exec(ctx, `UPDATE invitations SET status='revoked' WHERE id=$1`, invitationID)
		return err
	})
	if err != nil {
		return err
	}
	return c.NoContent(http.StatusNoContent)
}
