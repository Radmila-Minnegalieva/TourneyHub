package api

import (
	"context"
	"encoding/json"
	"errors"
	"time"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

const disputeJSON = `jsonb_build_object('id',d.id,'match_id',d.match_id,'report_id',d.report_id,'opened_by',d.opened_by,'reason',d.reason,'status',d.status,'resolution',d.resolution,'resolved_by',d.resolved_by,'created_at',d.created_at,'evidence_file_ids',coalesce((SELECT jsonb_agg(f.file_id ORDER BY f.file_id) FROM dispute_files f WHERE f.dispute_id=d.id),'[]'::jsonb))`

func readDispute(ctx context.Context, q DBTX, matchID uuid.UUID) (contract.Dispute, error) {
	var raw []byte
	var d contract.Dispute
	if err := q.QueryRow(ctx, `SELECT `+disputeJSON+` FROM disputes d WHERE d.match_id=$1`, matchID).Scan(&raw); err != nil {
		return d, dbError(err)
	}
	err := json.Unmarshal(raw, &d)
	return d, err
}
func (a *API) GetDispute(c echo.Context, id uuid.UUID) error {
	ctx := c.Request().Context()
	m, err := readMatch(ctx, a.db, id, false)
	if err != nil {
		return err
	}
	t, err := readTournament(ctx, a.db, m.TournamentId, false)
	if err != nil {
		return err
	}
	if err = matchReadAccess(ctx, a.db, c, t, m); err != nil {
		return err
	}
	d, err := readDispute(ctx, a.db, id)
	if err != nil {
		return err
	}
	return c.JSON(200, d)
}
func (a *API) DisputeResult(c echo.Context, id, reportID uuid.UUID) error {
	var req contract.DisputeRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var result contract.Dispute
	err := a.matchTransaction(c, id, func(tx pgx.Tx, t contract.Tournament, m contract.Match) error {
		if err := matchVersion(m, req.Version); err != nil {
			return err
		}
		if t.Status != contract.TournamentStatusInProgress && t.Status != contract.TournamentStatusCompleted {
			return conflict("tournament cannot accept disputes")
		}
		ctx := c.Request().Context()
		r, err := readReport(ctx, tx, reportID, id)
		if err != nil {
			return err
		}
		if m.Status == contract.MatchStatusCompleted {
			side, e := matchCaptain(ctx, tx, m, currentUser(c))
			if e != nil {
				return e
			}
			if side == 0 {
				return forbidden("participating captain only")
			}
			if r.Status != contract.ResultReportStatusConfirmed {
				return conflict("only the final report can be disputed")
			}
		} else {
			if m.Status != contract.MatchStatusAwaitingConfirmation || r.Status != contract.ResultReportStatusPending {
				return conflict("report cannot be disputed")
			}
			if err = opposingCaptain(ctx, tx, c, m, r); err != nil {
				return err
			}
			if r.ConfirmationDeadline == nil || !r.ConfirmationDeadline.After(time.Now()) {
				return conflict("confirmation deadline has expired")
			}
		}
		if err = validateEvidence(ctx, tx, req.EvidenceFileIds, currentUser(c)); err != nil {
			return err
		}
		did := uuid.New()
		if _, err = tx.Exec(ctx, `INSERT INTO disputes(id,match_id,report_id,opened_by,reason) VALUES($1,$2,$3,$4,$5)`, did, id, reportID, currentUser(c), req.Reason); err != nil {
			return err
		}
		if req.EvidenceFileIds != nil {
			for _, fid := range *req.EvidenceFileIds {
				if _, err = tx.Exec(ctx, `INSERT INTO dispute_files(dispute_id,file_id) VALUES($1,$2)`, did, fid); err != nil {
					return err
				}
			}
		}
		if _, err = tx.Exec(ctx, `UPDATE result_reports SET status='disputed' WHERE id=$1`, reportID); err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE matches SET status='disputed',version=version+1,updated_at=now() WHERE id=$1`, id); err != nil {
			return err
		}
		m.Status = contract.MatchStatusDisputed
		m.Version++
		if err = matchChanged(ctx, tx, currentUser(c), m, "result.disputed"); err != nil {
			return err
		}
		referee := m.RefereeId
		if referee == nil {
			referee = t.RefereeId
		}
		if referee != nil {
			if err = notify(ctx, tx, *referee, "result_disputed", "Открыт спор по результату матча", id); err != nil {
				return err
			}
		}
		result, err = readDispute(ctx, tx, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(201, result)
}
func (a *API) ResolveDispute(c echo.Context, id uuid.UUID) error {
	var req contract.ResolveDisputeRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var result contract.Match
	err := a.matchTransaction(c, id, func(tx pgx.Tx, t contract.Tournament, m contract.Match) error {
		if err := requireMatchReferee(c, t, m); err != nil {
			return err
		}
		if err := matchVersion(m, req.Version); err != nil {
			return err
		}
		if m.Status != contract.MatchStatusDisputed {
			return conflict("match has no unresolved dispute")
		}
		ctx := c.Request().Context()
		d, err := readDispute(ctx, tx, id)
		if err != nil {
			return err
		}
		if d.Status != contract.DisputeStatusOpen {
			return conflict("dispute already resolved")
		}
		if _, err = tx.Exec(ctx, `UPDATE result_reports SET status='superseded' WHERE match_id=$1 AND status IN ('pending','disputed')`, id); err != nil {
			return err
		}
		report := contract.ReportResultRequest{Version: req.Version, HomeScore: req.HomeScore, AwayScore: req.AwayScore, Games: req.Games, EvidenceFileIds: req.EvidenceFileIds}
		r, err := insertReport(ctx, tx, currentUser(c), t, m, report, "dispute", false)
		if err != nil {
			return err
		}
		result, err = finalizeResult(ctx, tx, currentUser(c), t, m, r)
		if err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE disputes SET status='resolved',resolved_by=$2,resolution=$3,resolved_at=now() WHERE id=$1`, d.Id, currentUser(c), req.Reason); err != nil {
			return err
		}
		return audit(ctx, tx, currentUser(c), "dispute.resolved", "dispute", d.Id, d, map[string]any{"resolution": req.Reason, "report_id": r.Id})
	})
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}
func (a *API) ListAssignedDisputes(c echo.Context, p contract.ListAssignedDisputesParams) error {
	if err := requireRole(c, contract.Referee); err != nil {
		return err
	}
	ctx := c.Request().Context()
	limit, offset := pagination(p.Limit, p.Offset)
	filter := ` FROM disputes d JOIN matches m ON m.id=d.match_id JOIN tournaments t ON t.id=m.tournament_id WHERE ($1 OR coalesce(m.referee_id,t.referee_id)=$2) AND ($3::text IS NULL OR d.status=$3)`
	args := []any{hasRole(c, contract.Admin), currentUser(c), p.Status}
	result := contract.DisputePage{Items: []contract.Dispute{}, Limit: limit, Offset: offset}
	if err := a.db.QueryRow(ctx, `SELECT count(*)`+filter, args...).Scan(&result.Total); err != nil {
		return err
	}
	rows, err := a.db.Query(ctx, `SELECT `+disputeJSON+filter+` ORDER BY d.created_at DESC,d.id LIMIT $4 OFFSET $5`, append(args, limit, offset)...)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var raw []byte
		var d contract.Dispute
		if err = rows.Scan(&raw); err != nil {
			return err
		}
		if err = json.Unmarshal(raw, &d); err != nil {
			return err
		}
		result.Items = append(result.Items, d)
	}
	if err = rows.Err(); err != nil {
		return err
	}
	return c.JSON(200, result)
}

// AutoConfirm атомарно фиксирует просроченные протоколы. Блокировки турнира и
// матча совпадают с пользовательским подтверждением и открытием спора.
func (a *API) AutoConfirm(ctx context.Context) error {
	rows, err := a.db.Query(ctx, `SELECT r.id,r.match_id,m.tournament_id FROM result_reports r JOIN matches m ON m.id=r.match_id JOIN tournaments t ON t.id=m.tournament_id WHERE t.status='in_progress' AND t.deleted_at IS NULL AND r.status='pending' AND r.confirmation_deadline<=now() AND m.status='awaiting_confirmation' ORDER BY r.confirmation_deadline,r.id LIMIT 100`)
	if err != nil {
		return err
	}
	type item struct{ report, match, tournament uuid.UUID }
	items := []item{}
	for rows.Next() {
		var i item
		if err = rows.Scan(&i.report, &i.match, &i.tournament); err != nil {
			rows.Close()
			return err
		}
		items = append(items, i)
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return err
	}
	for _, i := range items {
		if err = a.autoConfirmOne(ctx, i.report, i.match, i.tournament); err != nil {
			return err
		}
	}
	return nil
}
func (a *API) autoConfirmOne(ctx context.Context, reportID, matchID, tournamentID uuid.UUID) error {
	tx, err := a.db.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(context.WithoutCancel(ctx))
	t, err := readTournament(ctx, tx, tournamentID, true)
	if err != nil {
		var httpErr *echo.HTTPError
		if errors.As(err, &httpErr) && httpErr.Code == 404 {
			return nil
		}
		return err
	}
	if t.Status != contract.TournamentStatusInProgress {
		return nil
	}
	m, err := readMatch(ctx, tx, matchID, true)
	if err != nil {
		return err
	}
	r, err := readReport(ctx, tx, reportID, matchID)
	if err != nil {
		return err
	}
	if m.Status != contract.MatchStatusAwaitingConfirmation || r.Status != contract.ResultReportStatusPending || r.ConfirmationDeadline == nil || r.ConfirmationDeadline.After(time.Now()) {
		return nil
	}
	if err = tournamentPlaying(t); err != nil {
		return err
	}
	if _, err = finalizeResult(ctx, tx, uuid.Nil, t, m, r); err != nil {
		return err
	}
	return tx.Commit(ctx)
}
