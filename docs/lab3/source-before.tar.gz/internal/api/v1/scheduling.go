package api

import (
	"context"
	"net/http"
	"strings"
	"time"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

// Один матч резервирует час; интервал соседних стартов разных участников может быть меньше.
const matchSlot = time.Hour

func scheduleAllowed(t contract.Tournament, m contract.Match, start time.Time, venue, url *string) error {
	if err := tournamentPlaying(t); err != nil {
		return err
	}
	if m.Status != contract.MatchStatusScheduled {
		return conflict("only scheduled matches can be moved")
	}
	if (venue == nil || strings.TrimSpace(*venue) == "") && (url == nil || strings.TrimSpace(*url) == "") {
		return invalid("venue or online_url is required")
	}
	if t.StartsAt == nil || t.EndsAt == nil || start.Before(*t.StartsAt) || start.Add(matchSlot).After(*t.EndsAt) {
		return invalid("match must fit inside tournament dates")
	}
	return nil
}
func scheduleConflict(ctx context.Context, q DBTX, t contract.Tournament, m contract.Match, start time.Time) error {
	if err := scheduleDependencyConflict(ctx, q, m, start); err != nil {
		return err
	}
	referee := m.RefereeId
	if referee == nil {
		referee = t.RefereeId
	}
	var overlap bool
	err := q.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM matches other JOIN tournaments ot ON ot.id=other.tournament_id WHERE other.id<>$1 AND ot.status='in_progress' AND other.status NOT IN ('completed','bye') AND other.starts_at > $2::timestamptz-interval '1 hour' AND other.starts_at < $2::timestamptz+interval '1 hour' AND (($3::uuid IS NOT NULL AND coalesce(other.referee_id,ot.referee_id)=$3) OR EXISTS(SELECT 1 FROM application_players mine JOIN application_players theirs ON theirs.user_id=mine.user_id WHERE mine.application_id IN ($4,$5) AND theirs.application_id IN (other.home_application_id,other.away_application_id))))`, m.Id, start, referee, m.HomeApplicationId, m.AwayApplicationId).Scan(&overlap)
	if err != nil {
		return err
	}
	if overlap {
		return conflict("participant or referee already has a match in this one-hour slot")
	}
	return nil
}
func scheduleLock(ctx context.Context, q DBTX) error {
	_, err := q.Exec(ctx, `SELECT pg_advisory_xact_lock(170221)`)
	return err
}
func writeSchedule(ctx context.Context, q DBTX, c echo.Context, t contract.Tournament, m contract.Match, start time.Time, venue, url *string) (contract.Match, error) {
	start = start.UTC()
	if err := scheduleAllowed(t, m, start, venue, url); err != nil {
		return m, err
	}
	if err := scheduleConflict(ctx, q, t, m, start); err != nil {
		return m, err
	}
	_, err := q.Exec(ctx, `UPDATE matches SET starts_at=$2,venue=$3,online_url=$4,version=version+1,updated_at=now() WHERE id=$1`, m.Id, start.UTC(), venue, url)
	if err != nil {
		return m, err
	}
	m.StartsAt = &start
	m.Venue = venue
	m.OnlineUrl = url
	m.Version++
	if err = matchChanged(ctx, q, currentUser(c), m, "match.scheduled"); err != nil {
		return m, err
	}
	return m, notifyMatch(ctx, q, m, "match_scheduled", "Назначено или изменено время матча")
}
func (a *API) ScheduleMatch(c echo.Context, id uuid.UUID) error {
	var req contract.ScheduleMatchRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var result contract.Match
	err := a.matchTransaction(c, id, func(tx pgx.Tx, t contract.Tournament, m contract.Match) error {
		if err := requireTournamentOwner(c, t); err != nil {
			return err
		}
		if err := matchVersion(m, req.Version); err != nil {
			return err
		}
		ctx := c.Request().Context()
		if err := scheduleLock(ctx, tx); err != nil {
			return err
		}
		var err error
		result, err = writeSchedule(ctx, tx, c, t, m, req.StartsAt, req.Venue, req.OnlineUrl)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, result)
}
func (a *API) ScheduleRound(c echo.Context, id uuid.UUID) error {
	var req contract.ScheduleRoundRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	ctx := c.Request().Context()
	result := []contract.Match{}
	err := a.withTx(c, func(tx pgx.Tx) error {
		t, err := readTournament(ctx, tx, id, true)
		if err != nil {
			return err
		}
		if err = requireTournamentOwner(c, t); err != nil {
			return err
		}
		if t.Version != req.Version {
			return conflict("tournament version is stale")
		}
		if err = scheduleLock(ctx, tx); err != nil {
			return err
		}
		matches, err := matchList(ctx, tx, `SELECT `+matchColumns+` FROM matches m WHERE m.tournament_id=$1 AND m.stage_id=$2 AND m.round=$3 AND m.status<>'bye' ORDER BY m.position FOR UPDATE`, id, req.StageId, req.Round)
		if err != nil {
			return err
		}
		if len(matches) == 0 {
			return notFound("round has no matches")
		}
		// Сначала освобождаем старые слоты пакета, чтобы перестановка не конфликтовала сама с собой.
		_, err = tx.Exec(ctx, `UPDATE matches SET starts_at=NULL WHERE tournament_id=$1 AND stage_id=$2 AND round=$3 AND status='scheduled'`, id, req.StageId, req.Round)
		if err != nil {
			return err
		}
		for i, m := range matches {
			start := req.StartsAt.Add(time.Duration(i*req.IntervalMinutes) * time.Minute)
			updated, e := writeSchedule(ctx, tx, c, t, m, start, &req.Venue, nil)
			if e != nil {
				return e
			}
			result = append(result, updated)
		}
		_, err = tx.Exec(ctx, `UPDATE tournaments SET version=version+1,updated_at=now() WHERE id=$1`, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}
func validateReferee(ctx context.Context, q DBTX, id uuid.UUID) error {
	var valid bool
	err := q.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM users u JOIN user_roles r ON r.user_id=u.id WHERE u.id=$1 AND u.blocked_at IS NULL AND u.email_verified_at IS NOT NULL AND r.role='referee')`, id).Scan(&valid)
	if err != nil {
		return err
	}
	if !valid {
		return invalid("referee must be an active verified user with referee role")
	}
	return nil
}
func (a *API) AssignMatchReferee(c echo.Context, id uuid.UUID) error {
	var req contract.AssignRefereeRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var result contract.Match
	err := a.matchTransaction(c, id, func(tx pgx.Tx, t contract.Tournament, m contract.Match) error {
		if err := requireTournamentOwner(c, t); err != nil {
			return err
		}
		if err := matchVersion(m, req.Version); err != nil {
			return err
		}
		if m.Status == contract.MatchStatusCompleted || m.Status == contract.MatchStatusBye {
			return conflict("cannot reassign a finished match")
		}
		ctx := c.Request().Context()
		if err := scheduleLock(ctx, tx); err != nil {
			return err
		}
		if err := validateReferee(ctx, tx, req.RefereeId); err != nil {
			return err
		}
		m.RefereeId = &req.RefereeId
		if m.StartsAt != nil {
			if err := scheduleConflict(ctx, tx, t, m, *m.StartsAt); err != nil {
				return err
			}
		}
		if _, err := tx.Exec(ctx, `UPDATE matches SET referee_id=$2,version=version+1,updated_at=now() WHERE id=$1`, id, req.RefereeId); err != nil {
			return err
		}
		m.Version++
		result = m
		if err := matchChanged(ctx, tx, currentUser(c), m, "match.referee_assigned"); err != nil {
			return err
		}
		return notify(ctx, tx, req.RefereeId, "referee_assigned", "Вы назначены судьёй матча", id)
	})
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}

// В плей-офф будущие участники могут ещё не быть известны. Связи сетки
// резервируют порядок слотов независимо от заполнения home/away.
func scheduleDependencyConflict(ctx context.Context, q DBTX, m contract.Match, start time.Time) error {
	var overlap bool
	err := q.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM matches related WHERE related.starts_at IS NOT NULL AND (((related.next_match_id=$1 OR related.loser_next_match_id=$1) AND related.starts_at+interval '1 hour'>$2) OR (related.id IN ($3,$4) AND related.starts_at<$2::timestamptz+interval '1 hour')))`, m.Id, start, m.NextMatchId, m.LoserNextMatchId).Scan(&overlap)
	if err != nil {
		return err
	}
	if overlap {
		return conflict("a dependent match must start after the preceding one-hour slot")
	}
	return nil
}
