package api

import (
	"bytes"
	"context"
	"encoding/csv"
	"fmt"
	"net/http"
	"strconv"
	"time"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
)

func (a *API) ExportTournament(c echo.Context, id uuid.UUID) error {
	ctx := c.Request().Context()
	if err := tournamentPublic(ctx, a.db, id); err != nil {
		return err
	}
	var status string
	if err := a.db.QueryRow(ctx, `SELECT status FROM tournaments WHERE id=$1`, id).Scan(&status); err != nil {
		return err
	}
	if status != "completed" {
		return conflict("tournament is not completed")
	}
	var buffer bytes.Buffer
	buffer.WriteString("\xef\xbb\xbf")
	writer := csv.NewWriter(&buffer)
	if err := writer.Write([]string{"row_type", "place", "team", "match_id", "home_team", "away_team", "home_score", "away_score", "status"}); err != nil {
		return err
	}
	if err := writeTournamentCSV(ctx, a.db, id, writer); err != nil {
		return err
	}

	writer.Flush()
	if err := writer.Error(); err != nil {
		return err
	}
	c.Response().Header().Set("Content-Disposition", `attachment; filename="tournament-`+id.String()+`.csv"`)
	return c.Blob(200, "text/csv; charset=utf-8", buffer.Bytes())
}

// writeTournamentCSV выгружает места и все итоговые матчи, включая bye.
func writeTournamentCSV(ctx context.Context, q DBTX, id uuid.UUID, writer *csv.Writer) error {
	rows, err := q.Query(ctx, `SELECT row_type,place,team,match_id,home_team,away_team,home_score,away_score,status FROM (
 SELECT 'standing'::text row_type,coalesce(a.final_place::text,'') place,t.name team,''::text match_id,''::text home_team,''::text away_team,''::text home_score,''::text away_score,''::text status,0 kind,coalesce(a.final_place,999) stage,0 round,0 position,a.id
 FROM applications a JOIN teams t ON t.id=a.team_id WHERE a.tournament_id=$1 AND a.status='accepted'
 UNION ALL
 SELECT 'match','', '',m.id::text,coalesce(h.name,''),coalesce(w.name,''),coalesce(m.home_score::text,''),coalesce(m.away_score::text,''),m.status,1,s.position,m.round,m.position,m.id
 FROM matches m JOIN stages s ON s.id=m.stage_id LEFT JOIN applications ha ON ha.id=m.home_application_id LEFT JOIN teams h ON h.id=ha.team_id LEFT JOIN applications wa ON wa.id=m.away_application_id LEFT JOIN teams w ON w.id=wa.team_id
 WHERE m.tournament_id=$1 AND m.status IN ('completed','bye')
 ) results ORDER BY kind,stage,round,position,id`, id)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		record := make([]string, 9)
		if err := rows.Scan(&record[0], &record[1], &record[2], &record[3], &record[4], &record[5], &record[6], &record[7], &record[8]); err != nil {
			return err
		}
		for i := range record {
			record[i] = csvCell(record[i])
		}
		if err := writer.Write(record); err != nil {
			return err
		}
	}
	return rows.Err()
}

func (a *API) StreamTournamentEvents(c echo.Context, id uuid.UUID, p contract.StreamTournamentEventsParams) error {
	ctx := c.Request().Context()
	if err := tournamentPublic(ctx, a.db, id); err != nil {
		return err
	}
	flusher, ok := c.Response().Writer.(http.Flusher)
	if !ok {
		return echo.NewHTTPError(500, "streaming unavailable")
	}
	var after int64
	if p.LastEventID != nil {
		var err error
		after, err = strconv.ParseInt(*p.LastEventID, 10, 64)
		if err != nil || after < 0 {
			return echo.NewHTTPError(400, "invalid Last-Event-ID")
		}
	}
	c.Response().Header().Set("Content-Type", "text/event-stream")
	c.Response().Header().Set("Cache-Control", "no-cache")
	c.Response().Header().Set("X-Accel-Buffering", "no")
	c.Response().WriteHeader(200)
	if _, err := fmt.Fprint(c.Response(), ": connected\n\n"); err != nil {
		return nil
	}
	flusher.Flush()
	if p.LastEventID == nil {
		if err := a.db.QueryRow(ctx, `SELECT coalesce(max(id),0) FROM tournament_events WHERE tournament_id=$1`, id).Scan(&after); err != nil {
			return err
		}
	}
	tick := time.NewTicker(time.Second)
	defer tick.Stop()
	heartbeat := time.NewTicker(15 * time.Second)
	defer heartbeat.Stop()
	for {
		select {
		case <-ctx.Done():
			return nil
		case <-heartbeat.C:
			if _, err := fmt.Fprint(c.Response(), ": heartbeat\n\n"); err != nil {
				return nil
			}
			flusher.Flush()
		case <-tick.C:
			if err := tournamentPublic(ctx, a.db, id); err != nil {
				return nil
			}
			next, err := a.replayEvents(c, id, after)
			if err != nil {
				return err
			}
			after = next
			flusher.Flush()
		}
	}
}

func (a *API) replayEvents(c echo.Context, id uuid.UUID, after int64) (int64, error) {
	ctx := c.Request().Context()
	var min, max int64
	if err := a.db.QueryRow(ctx, `SELECT coalesce(min(id),0),coalesce(max(id),0) FROM tournament_events WHERE tournament_id=$1`, id).Scan(&min, &max); err != nil {
		return after, err
	}
	if after > max || (after > 0 && min > after) {
		_, err := fmt.Fprintf(c.Response(), "id: %d\nevent: resync_required\ndata: {}\n\n", max)
		return max, err
	}
	rows, err := a.db.Query(ctx, `SELECT id,kind,payload FROM tournament_events WHERE tournament_id=$1 AND id>$2 ORDER BY id LIMIT 100`, id, after)
	if err != nil {
		return after, err
	}
	defer rows.Close()
	for rows.Next() {
		var eventID int64
		var kind string
		var payload []byte
		if err := rows.Scan(&eventID, &kind, &payload); err != nil {
			return after, err
		}
		if _, err := fmt.Fprintf(c.Response(), "id: %d\nevent: %s\ndata: %s\n\n", eventID, kind, payload); err != nil {
			return after, err
		}
		after = eventID
	}
	return after, rows.Err()
}
