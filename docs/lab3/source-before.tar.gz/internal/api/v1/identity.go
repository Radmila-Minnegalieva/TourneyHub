package api

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"
	"unicode/utf8"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
	"golang.org/x/crypto/bcrypt"
)

const profileColumns = `u.id,u.email,u.nickname,u.name,u.timezone,u.email_notifications,
 u.email_verified_at IS NOT NULL,u.blocked_at IS NOT NULL,u.version,
 CASE WHEN u.avatar_file_id IS NULL THEN NULL ELSE '/api/v1/files/'||u.avatar_file_id END,
 ARRAY(SELECT role FROM user_roles WHERE user_id=u.id ORDER BY role)`

type identityScanner interface{ Scan(...any) error }

func scanProfile(row identityScanner) (contract.Profile, error) {
	var p contract.Profile
	var roles []string
	err := row.Scan(&p.Id, &p.Email, &p.Nickname, &p.Name, &p.Timezone,
		&p.EmailNotifications, &p.EmailVerified, &p.Blocked, &p.Version, &p.AvatarUrl, &roles)
	p.Roles = make([]contract.Role, len(roles))
	for i, role := range roles {
		p.Roles[i] = contract.Role(role)
	}
	return p, err
}

func loadProfile(ctx context.Context, q DBTX, id uuid.UUID) (contract.Profile, error) {
	p, err := scanProfile(q.QueryRow(ctx, `SELECT `+profileColumns+` FROM users u WHERE u.id=$1`, id))
	return p, dbError(err)
}

// secretToken создаёт 256-битный секрет; в таблицах токенов сохраняется только SHA-256.
func secretToken() (string, error) {
	var b [32]byte
	if _, err := rand.Read(b[:]); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b[:]), nil
}

func tokenHash(token string) string {
	sum := sha256.Sum256([]byte(token))
	return hex.EncodeToString(sum[:])
}

func hashPassword(password string) (string, error) {
	// bcrypt ограничивает именно байты, тогда как JSON Schema считает символы.
	if utf8.RuneCountInString(password) < 12 || len(password) > 72 {
		return "", invalid("password must contain at least 12 characters and at most 72 bytes")
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	return string(hash), err
}

func queueAccountToken(ctx context.Context, q DBTX, id uuid.UUID, email, purpose string) error {
	token, err := secretToken()
	if err != nil {
		return err
	}
	_, err = q.Exec(ctx, `UPDATE user_tokens SET consumed_at=now() WHERE user_id=$1 AND purpose=$2 AND consumed_at IS NULL`, id, purpose)
	if err != nil {
		return err
	}
	ttl := time.Hour
	subject := "TourneyHub: восстановление пароля"
	if purpose == "verify_email" {
		ttl = 24 * time.Hour
		subject = "TourneyHub: подтверждение e-mail"
	}
	_, err = q.Exec(ctx, `INSERT INTO user_tokens(user_id,purpose,token_hash,expires_at) VALUES($1,$2,$3,$4)`, id, purpose, tokenHash(token), time.Now().UTC().Add(ttl))
	if err != nil {
		return err
	}
	return outbox(ctx, q, "email", id, map[string]any{"to": email, "subject": subject, "text": "Откройте одноразовую ссылку: " + accountTokenURL(purpose, token), "purpose": purpose, "token": token})
}

func accountTokenURL(purpose, token string) string {
	base := strings.TrimRight(os.Getenv("PUBLIC_WEB_URL"), "/")
	if base == "" {
		base = "http://localhost:5173"
	}
	path := "/auth/reset-password"
	if purpose == "verify_email" {
		path = "/auth/verify-email"
	}
	return base + path + "?token=" + url.QueryEscape(token)
}

func (a *API) Register(c echo.Context) error {
	var req contract.RegisterRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	if !bool(req.PersonalDataConsent) {
		return invalid("personal data consent is required")
	}
	hash, err := hashPassword(req.Password)
	if err != nil {
		return err
	}
	err = a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		var id uuid.UUID
		err := tx.QueryRow(ctx, `INSERT INTO users(email,password_hash,nickname,name,personal_data_consent_at) VALUES(lower($1),$2,$3,$4,now()) RETURNING id`, string(req.Email), hash, req.Nickname, req.Name).Scan(&id)
		if err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `INSERT INTO user_roles(user_id,role) VALUES($1,'participant')`, id); err != nil {
			return err
		}
		return queueAccountToken(ctx, tx, id, string(req.Email), "verify_email")
	})
	if err != nil {
		return err
	}
	return c.NoContent(http.StatusAccepted)
}

func (a *API) VerifyEmail(c echo.Context) error {
	var req contract.TokenRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		var id uuid.UUID
		err := tx.QueryRow(ctx, `UPDATE user_tokens SET consumed_at=now() WHERE token_hash=$1 AND purpose='verify_email' AND consumed_at IS NULL AND expires_at>now() RETURNING user_id`, tokenHash(req.Token)).Scan(&id)
		if errors.Is(err, pgx.ErrNoRows) {
			return invalid("verification token is invalid or expired")
		}
		if err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `UPDATE users SET email_verified_at=COALESCE(email_verified_at,now()),updated_at=now(),version=version+1 WHERE id=$1`, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.NoContent(http.StatusNoContent)
}

func (a *API) allowLogin(ctx context.Context, ip string) error {
	var attempts int
	err := a.db.QueryRow(ctx, `INSERT INTO auth_rate_limits(ip,window_start,attempts) VALUES($1,now(),1)
 ON CONFLICT(ip) DO UPDATE SET
 attempts=CASE WHEN auth_rate_limits.window_start<=now()-interval '1 minute' THEN 1 ELSE auth_rate_limits.attempts+1 END,
 window_start=CASE WHEN auth_rate_limits.window_start<=now()-interval '1 minute' THEN now() ELSE auth_rate_limits.window_start END
 RETURNING attempts`, ip).Scan(&attempts)
	if err != nil {
		return err
	}
	if attempts > 5 {
		return echo.NewHTTPError(http.StatusTooManyRequests, "too many login attempts")
	}
	return nil
}

func issueSession(ctx context.Context, tx pgx.Tx, userID uuid.UUID) (contract.Tokens, error) {
	var tokens contract.Tokens
	access, err := secretToken()
	if err != nil {
		return tokens, err
	}
	refresh, err := secretToken()
	if err != nil {
		return tokens, err
	}
	var sessionID uuid.UUID
	err = tx.QueryRow(ctx, `INSERT INTO refresh_sessions(user_id,token_hash,expires_at) VALUES($1,$2,now()+interval '30 days') RETURNING id`, userID, tokenHash(refresh)).Scan(&sessionID)
	if err != nil {
		return tokens, err
	}
	_, err = tx.Exec(ctx, `INSERT INTO access_sessions(user_id,refresh_session_id,token_hash,expires_at) VALUES($1,$2,$3,now()+interval '15 minutes')`, userID, sessionID, tokenHash(access))
	if err != nil {
		return tokens, err
	}
	return contract.Tokens{AccessToken: access, RefreshToken: refresh, ExpiresIn: 900, TokenType: "Bearer"}, nil
}

func (a *API) Login(c echo.Context) error {
	var req contract.LoginRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	ctx := c.Request().Context()
	if err := a.allowLogin(ctx, c.RealIP()); err != nil {
		return err
	}
	if len(req.Password) > 72 {
		return echo.NewHTTPError(http.StatusUnauthorized, "invalid credentials")
	}
	var id uuid.UUID
	var hash string
	var verified, blocked bool
	err := a.db.QueryRow(ctx, `SELECT id,password_hash,email_verified_at IS NOT NULL,blocked_at IS NOT NULL FROM users WHERE lower(email)=lower($1)`, string(req.Email)).Scan(&id, &hash, &verified, &blocked)
	if errors.Is(err, pgx.ErrNoRows) {
		// Равная работа bcrypt не раскрывает наличие учётной записи по времени ответа.
		_ = bcrypt.CompareHashAndPassword([]byte("$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy"), []byte(req.Password))
		return echo.NewHTTPError(http.StatusUnauthorized, "invalid credentials")
	}
	if err != nil {
		return dbError(err)
	}
	if bcrypt.CompareHashAndPassword([]byte(hash), []byte(req.Password)) != nil || blocked || !verified {
		return echo.NewHTTPError(http.StatusUnauthorized, "invalid credentials or account unavailable")
	}
	var tokens contract.Tokens
	err = a.withTx(c, func(tx pgx.Tx) error {
		// Повторная проверка под блокировкой сериализует вход с блокировкой/сменой пароля.
		var usable bool
		if err := tx.QueryRow(ctx, `SELECT blocked_at IS NULL AND email_verified_at IS NOT NULL AND password_hash=$2 FROM users WHERE id=$1 FOR UPDATE`, id, hash).Scan(&usable); err != nil {
			return err
		}
		if !usable {
			return echo.NewHTTPError(http.StatusUnauthorized, "account unavailable")
		}
		var err error
		tokens, err = issueSession(ctx, tx, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, tokens)
}

func (a *API) authenticate(ctx context.Context, token string) (Principal, error) {
	var p Principal
	var roles []string
	if token == "" || len(token) > 512 {
		return p, echo.NewHTTPError(http.StatusUnauthorized, "invalid access token")
	}
	err := a.db.QueryRow(ctx, `SELECT u.id,ARRAY(SELECT role FROM user_roles WHERE user_id=u.id ORDER BY role)
 FROM access_sessions s JOIN users u ON u.id=s.user_id JOIN refresh_sessions r ON r.id=s.refresh_session_id
 WHERE s.token_hash=$1 AND s.expires_at>now() AND s.revoked_at IS NULL AND r.revoked_at IS NULL
 AND r.expires_at>now() AND u.blocked_at IS NULL AND u.email_verified_at IS NOT NULL`, tokenHash(token)).Scan(&p.ID, &roles)
	if errors.Is(err, pgx.ErrNoRows) {
		return p, echo.NewHTTPError(http.StatusUnauthorized, "invalid access token")
	}
	if err != nil {
		return p, err
	}
	p.Roles = make([]contract.Role, len(roles))
	for i, role := range roles {
		p.Roles[i] = contract.Role(role)
	}
	return p, nil
}

func (a *API) RefreshTokens(c echo.Context) error {
	var req contract.TokenRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	var tokens contract.Tokens
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		var userID, sessionID uuid.UUID
		err := tx.QueryRow(ctx, `SELECT r.user_id,r.id FROM refresh_sessions r JOIN users u ON u.id=r.user_id
 WHERE r.token_hash=$1 AND r.revoked_at IS NULL AND r.expires_at>now() AND u.blocked_at IS NULL AND u.email_verified_at IS NOT NULL FOR UPDATE OF r,u`, tokenHash(req.Token)).Scan(&userID, &sessionID)
		if errors.Is(err, pgx.ErrNoRows) {
			return echo.NewHTTPError(http.StatusUnauthorized, "invalid refresh token")
		}
		if err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE refresh_sessions SET revoked_at=now() WHERE id=$1`, sessionID); err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE access_sessions SET revoked_at=now() WHERE refresh_session_id=$1 AND revoked_at IS NULL`, sessionID); err != nil {
			return err
		}
		tokens, err = issueSession(ctx, tx, userID)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, tokens)
}

func (a *API) Logout(c echo.Context) error {
	var req contract.TokenRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	err := a.withTx(c, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Request().Context(), `WITH revoked AS (UPDATE refresh_sessions SET revoked_at=COALESCE(revoked_at,now()) WHERE token_hash=$1 RETURNING id)
 UPDATE access_sessions SET revoked_at=COALESCE(revoked_at,now()) WHERE refresh_session_id IN (SELECT id FROM revoked)`, tokenHash(req.Token))
		return err
	})
	if err != nil {
		return err
	}
	return c.NoContent(http.StatusNoContent)
}

func (a *API) RequestPasswordReset(c echo.Context) error {
	var req contract.EmailRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		var id uuid.UUID
		err := tx.QueryRow(ctx, `SELECT id FROM users WHERE lower(email)=lower($1) AND blocked_at IS NULL FOR UPDATE`, string(req.Email)).Scan(&id)
		if errors.Is(err, pgx.ErrNoRows) {
			return nil
		}
		if err != nil {
			return err
		}
		return queueAccountToken(ctx, tx, id, string(req.Email), "reset_password")
	})
	if err != nil {
		return err
	}
	return c.NoContent(http.StatusAccepted)
}

func (a *API) ResetPassword(c echo.Context) error {
	var req contract.ResetPasswordRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	hash, err := hashPassword(req.Password)
	if err != nil {
		return err
	}
	err = a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		var id uuid.UUID
		err := tx.QueryRow(ctx, `UPDATE user_tokens SET consumed_at=now() WHERE token_hash=$1 AND purpose='reset_password' AND consumed_at IS NULL AND expires_at>now() RETURNING user_id`, tokenHash(req.Token)).Scan(&id)
		if errors.Is(err, pgx.ErrNoRows) {
			return invalid("password reset token is invalid or expired")
		}
		if err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE users SET password_hash=$2,version=version+1,updated_at=now() WHERE id=$1`, id, hash); err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE refresh_sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL`, id); err != nil {
			return err
		}
		if _, err = tx.Exec(ctx, `UPDATE access_sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL`, id); err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `UPDATE user_tokens SET consumed_at=now() WHERE user_id=$1 AND purpose='reset_password' AND consumed_at IS NULL`, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.NoContent(http.StatusNoContent)
}

func (a *API) GetProfile(c echo.Context) error {
	p, err := loadProfile(c.Request().Context(), a.db, currentUser(c))
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, p)
}

func (a *API) UpdateProfile(c echo.Context) error {
	var req contract.UpdateProfileRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	if req.Timezone != nil {
		if _, err := time.LoadLocation(*req.Timezone); err != nil {
			return invalid("unknown IANA timezone")
		}
	}
	var p contract.Profile
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx, id := c.Request().Context(), currentUser(c)
		if req.AvatarFileId != nil {
			var allowed bool
			if err := tx.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM files WHERE id=$1 AND owner_id=$2 AND purpose='avatar')`, *req.AvatarFileId, id).Scan(&allowed); err != nil {
				return err
			}
			if !allowed {
				return invalid("avatar must be an owned avatar file")
			}
		}
		tag, err := tx.Exec(ctx, `UPDATE users SET nickname=COALESCE($3,nickname),name=COALESCE($4,name),avatar_file_id=COALESCE($5,avatar_file_id),timezone=COALESCE($6,timezone),email_notifications=COALESCE($7,email_notifications),version=version+1,updated_at=now() WHERE id=$1 AND version=$2`, id, req.Version, req.Nickname, req.Name, req.AvatarFileId, req.Timezone, req.EmailNotifications)
		if err != nil {
			return err
		}
		if tag.RowsAffected() == 0 {
			return conflict("profile version changed")
		}
		p, err = loadProfile(ctx, tx, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(http.StatusOK, p)
}

func (a *API) SearchUsers(c echo.Context, params contract.SearchUsersParams) error {
	ctx := c.Request().Context()
	limit, offset := pagination(params.Limit, params.Offset)
	search := strings.ToLower(params.Nickname)
	var total int
	if err := a.db.QueryRow(ctx, `SELECT count(*) FROM users WHERE blocked_at IS NULL AND strpos(lower(nickname),$1)>0`, search).Scan(&total); err != nil {
		return dbError(err)
	}
	rows, err := a.db.Query(ctx, `SELECT id,nickname,name,CASE WHEN avatar_file_id IS NULL THEN NULL ELSE '/api/v1/files/'||avatar_file_id END FROM users WHERE blocked_at IS NULL AND strpos(lower(nickname),$1)>0 ORDER BY created_at DESC,id LIMIT $2 OFFSET $3`, search, limit, offset)
	if err != nil {
		return dbError(err)
	}
	defer rows.Close()
	items := make([]contract.PublicUser, 0)
	for rows.Next() {
		var item contract.PublicUser
		if err := rows.Scan(&item.Id, &item.Nickname, &item.Name, &item.AvatarUrl); err != nil {
			return dbError(err)
		}
		items = append(items, item)
	}
	if err := rows.Err(); err != nil {
		return dbError(err)
	}
	return c.JSON(http.StatusOK, contract.PublicUserPage{Items: items, Limit: limit, Offset: offset, Total: total})
}
