package api

import (
	"context"
	"strings"

	contract "github.com/Radmila-Minnegalieva/TourneyHub/backend/pkg/api/v1"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/labstack/echo/v4"
)

func (a *API) ListAdminTournaments(c echo.Context, p contract.ListAdminTournamentsParams) error {
	if err := requireRole(c, contract.Admin); err != nil {
		return err
	}
	return a.tournamentPage(c, contract.ListTournamentsParams(p), nil, true)
}

func (a *API) ListAdminUsers(c echo.Context, p contract.ListAdminUsersParams) error {
	if err := requireRole(c, contract.Admin); err != nil {
		return err
	}
	ctx := c.Request().Context()
	l, o := pagination(p.Limit, p.Offset)
	var total int
	if err := a.db.QueryRow(ctx, `SELECT count(*) FROM users WHERE ($1::text IS NULL OR nickname ILIKE '%'||$1||'%' OR email ILIKE '%'||$1||'%')`, p.Search).Scan(&total); err != nil {
		return err
	}
	rows, err := a.db.Query(ctx, `SELECT `+profileColumns+` FROM users u WHERE ($1::text IS NULL OR nickname ILIKE '%'||$1||'%' OR email ILIKE '%'||$1||'%') ORDER BY created_at DESC,id LIMIT $2 OFFSET $3`, p.Search, l, o)
	if err != nil {
		return err
	}
	defer rows.Close()
	items := make([]contract.Profile, 0)
	for rows.Next() {
		item, err := scanProfile(rows)
		if err != nil {
			return err
		}
		items = append(items, item)
	}
	if err := rows.Err(); err != nil {
		return err
	}
	return c.JSON(200, contract.ProfilePage{Items: items, Total: total, Limit: l, Offset: o})
}

func protectLastAdmin(ctx context.Context, tx pgx.Tx, id uuid.UUID) error {
	var isAdmin bool
	var count int
	if err := tx.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM user_roles WHERE user_id=$1 AND role='admin')`, id).Scan(&isAdmin); err != nil {
		return err
	}
	if !isAdmin {
		return nil
	}
	if err := tx.QueryRow(ctx, `SELECT count(*) FROM user_roles r JOIN users u ON u.id=r.user_id WHERE r.role='admin' AND u.blocked_at IS NULL AND u.email_verified_at IS NOT NULL AND u.id<>$1`, id).Scan(&count); err != nil {
		return err
	}
	if count == 0 {
		return conflict("cannot remove or block the last active administrator")
	}
	return nil
}

func lockAdmin(ctx context.Context, tx pgx.Tx, id uuid.UUID, version int) (contract.Profile, error) {
	if _, err := tx.Exec(ctx, `SELECT pg_advisory_xact_lock(76123841)`); err != nil {
		return contract.Profile{}, err
	}
	var actual int
	if err := tx.QueryRow(ctx, `SELECT version FROM users WHERE id=$1 FOR UPDATE`, id).Scan(&actual); err != nil {
		return contract.Profile{}, dbError(err)
	}
	if actual != version {
		return contract.Profile{}, conflict("stale user version")
	}
	return loadProfile(ctx, tx, id)
}

func (a *API) BlockUser(c echo.Context, id uuid.UUID) error {
	if err := requireRole(c, contract.Admin); err != nil {
		return err
	}
	var req contract.BlockUserRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	if req.Blocked && (req.Reason == nil || strings.TrimSpace(*req.Reason) == "") {
		return invalid("block reason is required")
	}
	var result contract.Profile
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		before, err := lockAdmin(ctx, tx, id, req.Version)
		if err != nil {
			return err
		}
		if req.Blocked && !before.Blocked {
			if err := protectLastAdmin(ctx, tx, id); err != nil {
				return err
			}
		}
		if _, err := tx.Exec(ctx, `UPDATE users SET blocked_at=CASE WHEN $2 THEN now() END,block_reason=CASE WHEN $2 THEN $3 END,version=version+1,updated_at=now() WHERE id=$1`, id, req.Blocked, req.Reason); err != nil {
			return err
		}
		if req.Blocked {
			if err := revokeUserSessions(ctx, tx, id); err != nil {
				return err
			}
		}
		result, err = loadProfile(ctx, tx, id)
		if err != nil {
			return err
		}
		return audit(ctx, tx, currentUser(c), "user_blocked", "user", id, map[string]any{"blocked": before.Blocked}, map[string]any{"blocked": req.Blocked, "reason": req.Reason})
	})
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}

func revokeUserSessions(ctx context.Context, q DBTX, id uuid.UUID) error {
	if _, err := q.Exec(ctx, `UPDATE refresh_sessions SET revoked_at=coalesce(revoked_at,now()) WHERE user_id=$1`, id); err != nil {
		return err
	}
	_, err := q.Exec(ctx, `UPDATE access_sessions SET revoked_at=coalesce(revoked_at,now()) WHERE user_id=$1`, id)
	return err
}

func (a *API) UpdateUserRoles(c echo.Context, id uuid.UUID) error {
	if err := requireRole(c, contract.Admin); err != nil {
		return err
	}
	var req contract.UpdateRolesRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	roles := make(map[contract.Role]bool)
	for _, role := range req.Roles {
		roles[role] = true
	}
	if !roles[contract.Participant] {
		return invalid("participant role is required")
	}
	var result contract.Profile
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		before, err := lockAdmin(ctx, tx, id, req.Version)
		if err != nil {
			return err
		}
		if !roles[contract.Admin] && !before.Blocked {
			if err := protectLastAdmin(ctx, tx, id); err != nil {
				return err
			}
		}
		if _, err := tx.Exec(ctx, `DELETE FROM user_roles WHERE user_id=$1`, id); err != nil {
			return err
		}
		for role := range roles {
			if _, err := tx.Exec(ctx, `INSERT INTO user_roles(user_id,role) VALUES($1,$2)`, id, role); err != nil {
				return err
			}
		}
		if _, err := tx.Exec(ctx, `UPDATE users SET version=version+1,updated_at=now() WHERE id=$1`, id); err != nil {
			return err
		}
		result, err = loadProfile(ctx, tx, id)
		if err != nil {
			return err
		}
		return audit(ctx, tx, currentUser(c), "roles_updated", "user", id, map[string]any{"roles": before.Roles}, map[string]any{"roles": result.Roles})
	})
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}

func (a *API) ModerateTournament(c echo.Context, id uuid.UUID) error {
	if err := requireRole(c, contract.Admin); err != nil {
		return err
	}
	var req contract.ModerateTournamentRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	if strings.TrimSpace(req.Reason) == "" {
		return invalid("moderation reason is required")
	}
	var result contract.Tournament
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		before, err := readTournament(ctx, tx, id, true)
		if err != nil {
			return err
		}
		if before.Version != req.Version {
			return conflict("stale tournament version")
		}
		if _, err := tx.Exec(ctx, `UPDATE tournaments SET hidden=$2,version=version+1,updated_at=now() WHERE id=$1`, id, req.Hidden); err != nil {
			return err
		}
		if err := audit(ctx, tx, currentUser(c), "tournament_moderated", "tournament", id, map[string]any{"hidden": before.Hidden}, map[string]any{"hidden": req.Hidden, "reason": req.Reason}); err != nil {
			return err
		}
		if err := event(ctx, tx, id, "tournament_updated", map[string]any{"hidden": req.Hidden}); err != nil {
			return err
		}
		if err := notify(ctx, tx, before.Organizer.Id, "tournament_moderated", req.Reason, id); err != nil {
			return err
		}
		result, err = readTournament(ctx, tx, id, false)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(200, result)
}

func (a *API) DeleteTournament(c echo.Context, id uuid.UUID) error {
	if err := requireRole(c, contract.Admin); err != nil {
		return err
	}
	var req contract.ReasonRequest
	if err := bindJSON(c, &req); err != nil {
		return err
	}
	if strings.TrimSpace(req.Reason) == "" {
		return invalid("delete reason is required")
	}
	err := a.withTx(c, func(tx pgx.Tx) error {
		ctx := c.Request().Context()
		before, err := readTournament(ctx, tx, id, true)
		if err != nil {
			return err
		}
		if before.Version != req.Version {
			return conflict("stale tournament version")
		}
		if _, err := tx.Exec(ctx, `UPDATE tournaments SET deleted_at=now(),hidden=true,version=version+1,updated_at=now() WHERE id=$1`, id); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `DELETE FROM tournament_player_claims WHERE tournament_id=$1`, id); err != nil {
			return err
		}
		if err := event(ctx, tx, id, "tournament_updated", map[string]any{"deleted": true}); err != nil {
			return err
		}
		if err := notify(ctx, tx, before.Organizer.Id, "tournament_deleted", req.Reason, id); err != nil {
			return err
		}
		return audit(ctx, tx, currentUser(c), "tournament_deleted", "tournament", id, nil, map[string]any{"reason": req.Reason})
	})
	if err != nil {
		return err
	}
	return c.NoContent(204)
}

func (a *API) ListAudit(c echo.Context, p contract.ListAuditParams) error {
	if err := requireRole(c, contract.Admin); err != nil {
		return err
	}
	ctx := c.Request().Context()
	l, o := pagination(p.Limit, p.Offset)
	var total int
	if err := a.db.QueryRow(ctx, `SELECT count(*) FROM audit_entries WHERE ($1::uuid IS NULL OR entity_id=$1) AND ($2::uuid IS NULL OR actor_id=$2)`, p.EntityId, p.ActorId).Scan(&total); err != nil {
		return err
	}
	items, err := jsonItems[contract.AuditEntry](ctx, a.db, `SELECT to_jsonb(a) FROM audit_entries a WHERE ($1::uuid IS NULL OR entity_id=$1) AND ($2::uuid IS NULL OR actor_id=$2) ORDER BY created_at DESC,id LIMIT $3 OFFSET $4`, p.EntityId, p.ActorId, l, o)
	if err != nil {
		return err
	}
	return c.JSON(200, contract.AuditEntryPage{Items: items, Total: total, Limit: l, Offset: o})
}
