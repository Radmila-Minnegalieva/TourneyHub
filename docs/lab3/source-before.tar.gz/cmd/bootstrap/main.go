// Command bootstrap создаёт первого администратора без публичной выдачи привилегий.
// Данные аккаунта передаются через ADMIN_EMAIL, ADMIN_NICKNAME и ADMIN_PASSWORD.
package main

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/mail"
	"os"
	"regexp"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/Radmila-Minnegalieva/TourneyHub/backend/internal/config"
	"github.com/Radmila-Minnegalieva/TourneyHub/backend/internal/container"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"golang.org/x/crypto/bcrypt"
)

func main() {
	if err := run(); err != nil {
		slog.Error("bootstrap failed", "error", err)
		os.Exit(1)
	}
	slog.Info("administrator is ready")
}

func run() error {
	email, nickname, password := strings.ToLower(strings.TrimSpace(os.Getenv("ADMIN_EMAIL"))), os.Getenv("ADMIN_NICKNAME"), os.Getenv("ADMIN_PASSWORD")
	parsed, err := mail.ParseAddress(email)
	if err != nil || parsed.Address != email || len(email) > 254 {
		return errors.New("ADMIN_EMAIL must be an email address")
	}
	if !regexp.MustCompile(`^[A-Za-z0-9_]{3,32}$`).MatchString(nickname) {
		return errors.New("ADMIN_NICKNAME must contain 3..32 Latin letters, digits or underscores")
	}
	if utf8.RuneCountInString(password) < 12 || len(password) > 72 {
		return errors.New("ADMIN_PASSWORD must contain at least 12 characters and at most 72 bytes")
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	deps, err := container.New(ctx, cfg)
	if err != nil {
		return err
	}
	defer deps.Close()
	tx, err := deps.Database.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(context.WithoutCancel(ctx))
	if _, err := tx.Exec(ctx, `SELECT pg_advisory_xact_lock(76123841)`); err != nil {
		return err
	}
	if err := createFirstAdmin(ctx, tx, email, nickname, string(hash)); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

func createFirstAdmin(ctx context.Context, tx pgx.Tx, email, nickname, hash string) error {
	var count int
	var same bool
	if err := tx.QueryRow(ctx, `SELECT count(*),coalesce(bool_or(lower(u.email)=$1 AND u.blocked_at IS NULL AND u.email_verified_at IS NOT NULL),false) FROM user_roles r JOIN users u ON u.id=r.user_id WHERE r.role='admin'`, email).Scan(&count, &same); err != nil {
		return err
	}
	if count > 0 {
		if same {
			return nil
		}
		return errors.New("an administrator already exists; use the authenticated admin API")
	}
	id := uuid.New()
	if _, err := tx.Exec(ctx, `INSERT INTO users(id,email,nickname,password_hash,email_verified_at,personal_data_consent_at) VALUES($1,$2,$3,$4,now(),now())`, id, email, nickname, hash); err != nil {
		return fmt.Errorf("create administrator: %w", err)
	}
	for _, role := range []string{"participant", "organizer", "referee", "admin"} {
		if _, err := tx.Exec(ctx, `INSERT INTO user_roles(user_id,role) VALUES($1,$2)`, id, role); err != nil {
			return err
		}
	}
	_, err := tx.Exec(ctx, `INSERT INTO audit_entries(actor_id,action,entity_type,entity_id,after) VALUES($1,'administrator_bootstrapped','user',$1,'{"bootstrap":true}')`, id)
	return err
}
